import json
import math
import os
from pathlib import Path

root = Path(os.environ["MARKET_DATA_OUTPUT"])
market = json.loads((root / "market-state.json").read_text(encoding="utf-8"))
rankings = json.loads((root / "industry-rankings.json").read_text(encoding="utf-8"))
pool = json.loads((root / "stock-pool-current.json").read_text(encoding="utf-8"))
trade_date = market["trade_date"]
as_of = trade_date.replace("-", "")
assert market["data_status"] == "complete"
assert market["data_quality"]["complete_modules"] == 6
assert all(source["status"] == "ok" for source in market["data_quality"]["sources"])
assert rankings["metadata"]["trade_date"] == pool["metadata"]["trade_date"] == trade_date
rows = rankings["industry_rankings"]
assert len(rows) == 31 == len({row["industry_code"] for row in rows})
assert not rankings["calculation_failures"]
assert all(row["sample_count"] >= 750 and row["sample_end"] == as_of for row in rows)


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def percentile(values, current):
    return sum(value <= current for value in values) / len(values)


for row in rows:
    offensive = 100 * (
        0.30 * percentile([item["beta"] for item in rows], row["beta"])
        + 0.25 * percentile([item["annualized_alpha"] for item in rows], row["annualized_alpha"])
        + 0.20 * percentile([item["up_market_corr"] for item in rows], row["up_market_corr"])
        + 0.15 * percentile([item["rolling60_latest"] for item in rows], row["rolling60_latest"])
        + 0.10 * percentile([item["r_squared"] for item in rows], row["r_squared"])
    )
    defensive = 100 * (
        0.30 * (1 - percentile([item["beta"] for item in rows], row["beta"]))
        + 0.25 * (1 - percentile([item["down_market_corr"] for item in rows], row["down_market_corr"]))
        + 0.20 * (1 - percentile([item["large_down_corr"] for item in rows], row["large_down_corr"]))
        + 0.15 * (1 - percentile([item["high_vol_corr"] for item in rows], row["high_vol_corr"]))
        + 0.10 * (1 - percentile([item["r_squared"] for item in rows], row["r_squared"]))
    )
    neutral = 100 * (
        0.25 * percentile([item["annualized_alpha"] for item in rows], row["annualized_alpha"])
        + 0.25 * percentile([-abs(item["beta"] - 1) for item in rows], -abs(row["beta"] - 1))
        + 0.20 * percentile([-item["rolling60_stability"] for item in rows], -row["rolling60_stability"])
        + 0.15 * percentile([-abs(item["up_market_corr"] - item["down_market_corr"]) for item in rows], -abs(row["up_market_corr"] - row["down_market_corr"]))
        + 0.15 * percentile([-abs(item["r_squared"] - 0.5) for item in rows], -abs(row["r_squared"] - 0.5))
    )
    assert math.isclose(offensive, row["offensive_score"], abs_tol=1e-10)
    assert math.isclose(defensive, row["defensive_score"], abs_tol=1e-10)
    assert math.isclose(neutral, row["neutral_score"], abs_tol=1e-10)
    assert finite(row["sample_count"])

for style in ("offensive", "defensive", "neutral"):
    expected = sorted(rows, key=lambda row: (-row[f"{style}_score"], -row["annualized_alpha"], row["missing_ratio"], row["industry_code"]))
    for rank, row in enumerate(expected, 1):
        assert row[f"{style}_rank"] == rank

basic = pool["basic_rows"]
financial = pool["financial_rows"]
eligible = pool["eligible_rows"]
excluded = pool["excluded_rows"]
counts = pool["counts"]
assert len(basic) == counts["all_constituents"]
assert len({(row["industry_code"], row["stock_code"]) for row in basic}) == len(basic)
assert len(financial) == counts["basic_pass"]
assert {row["stock_code"] for row in financial} == {row["stock_code"] for row in basic if row["basic_result"] == "pass"}
assert len(eligible) == counts["financial_pass"] == counts["eligible_pool"]
assert all(row["financial_result"] == "pass" and row["final_tradable"] == "needs_event_review" for row in eligible)
assert len(excluded) == counts["excluded"]
assert counts["basic_fail_or_unassessed"] + counts["financial_fail_or_unassessed"] == len(excluded)
assert counts["final_tradable_yes"] == 0
assert all(row["event_risk_status"] == "not_assessed" for row in financial)
assert not any("退市" in row["stock_name"] for row in financial)
assert not pool["failures"][:-1]
assert all(len(row["basic_checks"]) == 4 for row in basic)
assert all(len(row["financial_checks"]) == 6 for row in financial)
assert all(item["status"] == "pass" for row in eligible for item in row["financial_checks"].values())
assert all(not row.get("latest_announcement_date") or row["latest_announcement_date"] <= as_of for row in financial)
assert all(row["latest_report_period"] == pool["metadata"]["financial_period"] for row in financial)
style_by_state = {"attack": ("进攻", "offensive"), "neutral": ("均衡", "neutral"), "defense": ("防守", "defensive")}
style_label, style_field = style_by_state[market["market_state"]]
assert pool["metadata"]["selected_style"] == style_label
expected_selected = sorted(rows, key=lambda row: row[f"{style_field}_rank"])[:5]
assert [row["industry_code"] for row in pool["selected_industries"]] == [row["industry_code"] for row in expected_selected]
assert math.isclose(sum(row["industry_guidance_position_pct"] for row in pool["selected_industries"]), market["guidance_position_pct"], abs_tol=1e-10)
print(json.dumps({
    "status": "all_checks_passed",
    "trade_date": trade_date,
    "market_state": market["market_state"],
    "industries": len(rows),
    "defensive_top5": [row["industry_name"] for row in sorted(rows, key=lambda item: item["defensive_rank"])[:5]],
    "selected_style": style_label,
    "pool_counts": counts,
    "financial_api_failures": len(pool["failures"]) - 1,
}, ensure_ascii=False, indent=2))
