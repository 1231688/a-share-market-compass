from __future__ import annotations

import hashlib
import json
import math
import os
import re
import statistics
import time
import urllib.request
from collections import defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
CACHE_INPUT = Path(os.environ.get("MARKET_CORE_CACHE", str(WORKSPACE / "app/engine/data/cache")))
RAW_CACHE = Path(os.environ.get("MARKET_ENRICHMENT_CACHE", str(WORKSPACE / "app/runtime/enrichment-cache")))
OUTPUT = Path(os.environ.get("MARKET_DATA_OUTPUT", str(WORKSPACE / "app/public/data")))
CONFIG = Path(os.environ.get("TUSHARE_CONFIG", str(ROOT / "codex-config.toml")))
AS_OF = os.environ.get("MARKET_AS_OF", "20261116").replace("-", "")
if not re.fullmatch(r"\d{8}", AS_OF):
    raise RuntimeError("MARKET_AS_OF 必须为 YYYYMMDD")
TRADE_DATE = f"{AS_OF[:4]}-{AS_OF[4:6]}-{AS_OF[6:8]}"
EVALUATION_TIMESTAMP = f"{TRADE_DATE}T15:00:00+08:00"
START_DATE = f"{int(AS_OF[:4]) - 5}0101"
BENCHMARK_CODE = "CORE3_EW"
BENCHMARK_NAME = "上证指数/深证成指/创业板指等权日收益组合"
LIQUIDITY_THRESHOLD_CNY = 30_000_000
RAW_CACHE.mkdir(parents=True, exist_ok=True)
OUTPUT.mkdir(parents=True, exist_ok=True)


def financial_periods():
    year = int(AS_OF[:4])
    month_day = AS_OF[4:]
    if month_day < "0501":
        latest_year, latest_suffix, annual_year = year - 1, "0930", year - 2
    elif month_day < "0901":
        latest_year, latest_suffix, annual_year = year, "0331", year - 1
    elif month_day < "1101":
        latest_year, latest_suffix, annual_year = year, "0630", year - 1
    else:
        latest_year, latest_suffix, annual_year = year, "0930", year - 1
    latest = f"{latest_year}{latest_suffix}"
    annual = f"{annual_year}1231"
    return {
        "latest": latest,
        "latest_prior": f"{latest_year - 1}{latest_suffix}",
        "annual": annual,
        "annual_prior": f"{annual_year - 1}1231",
        "query_start": f"{annual_year - 1}0101",
    }


PERIODS = financial_periods()
STYLE_CONFIG = {
    "attack": {"label": "进攻", "score": "offensive_score", "rank": "offensive_rank"},
    "neutral": {"label": "均衡", "score": "neutral_score", "rank": "neutral_rank"},
    "defense": {"label": "防守", "score": "defensive_score", "rank": "defensive_rank"},
}


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def as_float(value):
    if value in (None, "", "-", "--"):
        return None
    try:
        number = float(str(value).replace(",", "").replace("%", ""))
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def percentile(values, current):
    sample = [value for value in values if finite(value)]
    if not sample or not finite(current):
        return None
    return sum(value <= current for value in sample) / len(sample)


def quantile(values, probability):
    sample = sorted(value for value in values if finite(value))
    if not sample:
        return None
    position = (len(sample) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sample[lower]
    weight = position - lower
    return sample[lower] * (1 - weight) + sample[upper] * weight


def covariance(left, right):
    if len(left) != len(right) or len(left) < 2:
        return None
    left_mean = statistics.fmean(left)
    right_mean = statistics.fmean(right)
    return sum((x - left_mean) * (y - right_mean) for x, y in zip(left, right)) / (len(left) - 1)


def correlation(left, right):
    if len(left) != len(right) or len(left) < 2:
        return None
    left_std = statistics.stdev(left)
    right_std = statistics.stdev(right)
    if not left_std or not right_std:
        return None
    return covariance(left, right) / (left_std * right_std)


def average_ranks(values):
    indexed = sorted(enumerate(values), key=lambda item: item[1])
    ranks = [0.0] * len(values)
    position = 0
    while position < len(indexed):
        end = position
        while end + 1 < len(indexed) and indexed[end + 1][1] == indexed[position][1]:
            end += 1
        rank = (position + end + 2) / 2
        for offset in range(position, end + 1):
            ranks[indexed[offset][0]] = rank
        position = end + 1
    return ranks


def spearman(left, right):
    if len(left) != len(right) or len(left) < 2:
        return None
    return correlation(average_ranks(left), average_ranks(right))


def rolling_correlation(left, right, window):
    result = []
    for index in range(window - 1, len(left)):
        value = correlation(left[index - window + 1 : index + 1], right[index - window + 1 : index + 1])
        if finite(value):
            result.append(value)
    return result


def daily_returns(rows):
    result = {}
    ordered = sorted(rows, key=lambda row: str(row["trade_date"]))
    for index in range(1, len(ordered)):
        previous = as_float(ordered[index - 1].get("close"))
        current = as_float(ordered[index].get("close"))
        if previous and finite(current):
            result[str(ordered[index]["trade_date"])] = current / previous - 1
    return result


def write_json(path, payload):
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")


def load_token():
    if os.environ.get("TUSHARE_TOKEN", "").strip():
        return os.environ["TUSHARE_TOKEN"].strip()
    text = CONFIG.read_text(encoding="utf-8")
    match = re.search(r"(?m)^\s*TUSHARE_TOKEN\s*=\s*['\"]([^'\"]+)['\"]", text)
    if not match:
        raise RuntimeError("私有配置中未找到 TUSHARE_TOKEN")
    return match.group(1)


TOKEN = load_token()


def api_call(api_name, fields="", **params):
    payload = json.dumps(
        {"api_name": api_name, "token": TOKEN, "params": params, "fields": fields},
        ensure_ascii=False,
    ).encode("utf-8")
    request = urllib.request.Request(
        "https://api.tushare.pro",
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "market-state-audit/1.0"},
    )
    last_error = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                result = json.loads(response.read().decode("utf-8"))
            if result.get("code") != 0:
                message = str(result.get("msg", "未知错误")).replace(TOKEN, "[已隐藏]")
                raise RuntimeError(message)
            data = result.get("data") or {}
            columns = data.get("fields") or []
            return [dict(zip(columns, values)) for values in (data.get("items") or [])]
        except Exception as exc:
            last_error = str(exc).replace(TOKEN, "[已隐藏]")
            retryable = any(word in last_error.lower() for word in ("每分钟", "rate", "timeout", "timed out", "限流"))
            if not retryable or attempt == 2:
                break
            delay = 10 * (attempt + 1)
            print(f"接口限流或超时，{delay} 秒后重试：{api_name}", flush=True)
            time.sleep(delay)
    raise RuntimeError(f"{api_name}: {last_error}")


def cached_call(api_name, fields="", refresh=False, **params):
    key = hashlib.sha256(
        json.dumps({"api": api_name, "fields": fields, "params": params}, sort_keys=True).encode("utf-8")
    ).hexdigest()[:24]
    path = RAW_CACHE / f"{api_name}-{key}.json"
    if path.exists() and not refresh:
        return json.loads(path.read_text(encoding="utf-8"))["rows"]
    rows = api_call(api_name, fields, **params)
    write_json(path, {"api": api_name, "params": params, "fields": fields, "rows": rows})
    time.sleep(0.14)
    return rows


def load_local_cache():
    datasets = {
        "classifications": [],
        "industries": defaultdict(list),
        "stocks": defaultdict(list),
        "limits": defaultdict(list),
        "master": {},
        "indices": defaultdict(list),
        "st": defaultdict(list),
        "suspensions": defaultdict(list),
    }
    index_codes = {"000001.SH", "399001.SZ", "399006.SZ"}
    for path in CACHE_INPUT.glob("*.json"):
        try:
            rows = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(rows, list) or not rows or not isinstance(rows[0], dict):
            continue
        first = rows[0]
        if "industry_name" in first and "index_code" in first:
            datasets["classifications"].extend(rows)
        elif "area" in first and "list_date" in first and "ts_code" in first:
            for row in rows:
                datasets["master"][row["ts_code"]] = row
        elif "up_limit" in first and "down_limit" in first:
            for row in rows:
                datasets["limits"][row["ts_code"]].append(row)
        elif "type_name" in first and "type" in first:
            for row in rows:
                datasets["st"][row["ts_code"]].append(row)
        elif "suspend_type" in first:
            for row in rows:
                datasets["suspensions"][row["ts_code"]].append(row)
        elif "close" in first and "trade_date" in first and "ts_code" in first:
            for row in rows:
                code = str(row.get("ts_code") or "")
                if code.endswith(".SI"):
                    datasets["industries"][code].append(row)
                elif code in index_codes:
                    datasets["indices"][code].append(row)
                elif "pct_chg" in first:
                    datasets["stocks"][code].append(row)
    return datasets


def calculate_rankings(local, refresh=False):
    names = {row["index_code"]: row["industry_name"] for row in local["classifications"]}
    benchmark_maps = {code: daily_returns(rows) for code, rows in local["indices"].items()}
    if set(benchmark_maps) != {"000001.SH", "399001.SZ", "399006.SZ"}:
        raise RuntimeError("三大指数历史不完整")
    common_benchmark_dates = sorted(set.intersection(*(set(rows) for rows in benchmark_maps.values())))
    benchmark = {
        date: statistics.fmean(benchmark_maps[code][date] for code in benchmark_maps)
        for date in common_benchmark_dates
    }
    metrics = []
    invalid = []
    failures = []
    for position, (code, name) in enumerate(sorted(names.items()), start=1):
        print(f"行业历史 {position}/{len(names)}：{name}", flush=True)
        try:
            rows = cached_call(
                "sw_daily",
                "ts_code,trade_date,open,high,low,close,pct_change,vol,amount",
                refresh=refresh,
                ts_code=code,
                start_date=START_DATE,
                end_date=AS_OF,
            )
            industry_returns = daily_returns(rows)
            dates = sorted(set(benchmark) & set(industry_returns))
            if len(dates) < 750:
                invalid.append({"industry_code": code, "industry_name": name, "sample_count": len(dates), "reason": "有效对齐收益样本不足750日"})
                continue
            benchmark_values = [benchmark[date] for date in dates]
            industry_values = [industry_returns[date] for date in dates]
            benchmark_variance = statistics.variance(benchmark_values)
            beta = covariance(industry_values, benchmark_values) / benchmark_variance if benchmark_variance else None
            pearson = correlation(industry_values, benchmark_values)
            alpha_daily = statistics.fmean(industry_values) - beta * statistics.fmean(benchmark_values)
            annual_alpha = (1 + alpha_daily) ** 252 - 1 if alpha_daily > -1 else -1
            rolling20 = rolling_correlation(industry_values, benchmark_values, 20)
            rolling60 = rolling_correlation(industry_values, benchmark_values, 60)
            rolling120 = rolling_correlation(industry_values, benchmark_values, 120)
            up_indices = [index for index, value in enumerate(benchmark_values) if value > 0]
            down_indices = [index for index, value in enumerate(benchmark_values) if value < 0]
            large_down_threshold = quantile(benchmark_values, 0.10)
            large_down_indices = [index for index, value in enumerate(benchmark_values) if value <= large_down_threshold]
            realized20 = [
                statistics.stdev(benchmark_values[index - 19 : index + 1]) if index >= 19 else None
                for index in range(len(benchmark_values))
            ]
            volatility_threshold = quantile(realized20, 0.75)
            high_vol_indices = [index for index, value in enumerate(realized20) if finite(value) and value >= volatility_threshold]

            def conditional_corr(indices):
                return correlation(
                    [industry_values[index] for index in indices],
                    [benchmark_values[index] for index in indices],
                )

            ordered_closes = sorted(rows, key=lambda row: row["trade_date"])
            close_values = [as_float(row.get("close")) for row in ordered_closes]
            recent_closes = [value for value in close_values[-61:] if finite(value)]
            running_peak = 0
            max_drawdown = 0
            for value in recent_closes:
                running_peak = max(running_peak, value)
                if running_peak:
                    max_drawdown = min(max_drawdown, value / running_peak - 1)
            return20 = math.prod(1 + value for value in industry_values[-20:]) - 1
            benchmark_return20 = math.prod(1 + value for value in benchmark_values[-20:]) - 1
            metrics.append({
                "industry_code": code,
                "industry_name": name,
                "sample_count": len(dates),
                "sample_start": dates[0],
                "sample_end": dates[-1],
                "pearson": pearson,
                "spearman": spearman(industry_values, benchmark_values),
                "beta": beta,
                "r_squared": pearson * pearson,
                "alpha_daily": alpha_daily,
                "annualized_alpha": annual_alpha,
                "rolling20_latest": rolling20[-1],
                "rolling60_latest": rolling60[-1],
                "rolling120_latest": rolling120[-1],
                "rolling60_stability": statistics.stdev(rolling60) if len(rolling60) >= 2 else None,
                "up_market_corr": conditional_corr(up_indices),
                "down_market_corr": conditional_corr(down_indices),
                "large_down_corr": conditional_corr(large_down_indices),
                "high_vol_corr": conditional_corr(high_vol_indices),
                "annualized_volatility": statistics.stdev(industry_values) * math.sqrt(252),
                "missing_ratio": 1 - len(dates) / len(benchmark),
                "large_down_threshold": large_down_threshold,
                "high_volatility_threshold_daily_std": volatility_threshold,
                "return_20d": return20,
                "benchmark_return_20d": benchmark_return20,
                "relative_return_20d": return20 - benchmark_return20,
                "max_drawdown_60d": max_drawdown,
                "quality_status": "ok",
            })
        except Exception as exc:
            failures.append({"industry_code": code, "industry_name": name, "stage": "行业历史或指标", "reason": str(exc)[:500]})
    required = ["beta", "annualized_alpha", "up_market_corr", "rolling60_latest", "r_squared", "down_market_corr", "large_down_corr", "high_vol_corr", "rolling60_stability"]
    eligible = [row for row in metrics if all(finite(row[field]) for field in required)]
    for row in metrics:
        if row not in eligible:
            failures.append({"industry_code": row["industry_code"], "industry_name": row["industry_name"], "stage": "横截面评分", "reason": "一个或多个必需指标不可用"})
    for row in eligible:
        row["offensive_score"] = 100 * (
            0.30 * percentile([item["beta"] for item in eligible], row["beta"])
            + 0.25 * percentile([item["annualized_alpha"] for item in eligible], row["annualized_alpha"])
            + 0.20 * percentile([item["up_market_corr"] for item in eligible], row["up_market_corr"])
            + 0.15 * percentile([item["rolling60_latest"] for item in eligible], row["rolling60_latest"])
            + 0.10 * percentile([item["r_squared"] for item in eligible], row["r_squared"])
        )
        row["defensive_score"] = 100 * (
            0.30 * (1 - percentile([item["beta"] for item in eligible], row["beta"]))
            + 0.25 * (1 - percentile([item["down_market_corr"] for item in eligible], row["down_market_corr"]))
            + 0.20 * (1 - percentile([item["large_down_corr"] for item in eligible], row["large_down_corr"]))
            + 0.15 * (1 - percentile([item["high_vol_corr"] for item in eligible], row["high_vol_corr"]))
            + 0.10 * (1 - percentile([item["r_squared"] for item in eligible], row["r_squared"]))
        )
        row["neutral_score"] = 100 * (
            0.25 * percentile([item["annualized_alpha"] for item in eligible], row["annualized_alpha"])
            + 0.25 * percentile([-abs(item["beta"] - 1) for item in eligible], -abs(row["beta"] - 1))
            + 0.20 * percentile([-item["rolling60_stability"] for item in eligible], -row["rolling60_stability"])
            + 0.15 * percentile([-abs(item["up_market_corr"] - item["down_market_corr"]) for item in eligible], -abs(row["up_market_corr"] - row["down_market_corr"]))
            + 0.15 * percentile([-abs(item["r_squared"] - 0.5) for item in eligible], -abs(row["r_squared"] - 0.5))
        )

    def assign(score_field, rank_field):
        ordered = sorted(eligible, key=lambda row: (-row[score_field], -row["annualized_alpha"], row["missing_ratio"], row["industry_code"]))
        for rank, row in enumerate(ordered, start=1):
            row[rank_field] = rank

    assign("offensive_score", "offensive_rank")
    assign("defensive_score", "defensive_rank")
    assign("neutral_score", "neutral_rank")
    payload = {
        "metadata": {
            "schema_version": "1.0",
            "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "trade_date": TRADE_DATE,
            "evaluation_timestamp": EVALUATION_TIMESTAMP,
            "source": "Tushare Pro sw_daily + 本地已核验三大指数快照",
            "classification": "申万2021一级行业",
            "classification_snapshot_date": TRADE_DATE,
            "benchmark_code": BENCHMARK_CODE,
            "benchmark_name": BENCHMARK_NAME,
            "return_weighting": "申万行业指数日收益；基准为三指数等权",
            "risk_free_rate": 0,
            "lookback_start": f"{START_DATE[:4]}-{START_DATE[4:6]}-{START_DATE[6:8]}",
            "minimum_aligned_returns": 750,
            "large_down_definition": "基准日收益不高于样本10%分位",
            "high_vol_definition": "基准20日实现波动率不低于样本75%分位",
            "percentile_definition": "样本中小于等于当前值的比例",
            "rolling60_stability_definition": "全部60日滚动相关系数的样本标准差；均衡评分取其负值",
            "supplemental_metrics_note": "20日收益、相对收益和60日最大回撤仅作补充，不参与三种风格评分",
        },
        "counts": {"eligible_industries": len(eligible), "invalid_or_empty": len(invalid), "calculation_failures": len(failures)},
        "industry_rankings": sorted(eligible, key=lambda row: row["defensive_rank"]),
        "invalid_or_empty_industries": invalid,
        "calculation_failures": failures,
    }
    write_json(OUTPUT / "industry-rankings.json", payload)
    print(f"行业评分完成：{len(eligible)} 个行业，{len(failures)} 个失败", flush=True)
    return payload


def latest_row(rows, date=AS_OF):
    eligible = [row for row in rows if str(row.get("trade_date") or "") <= date]
    return sorted(eligible, key=lambda row: row["trade_date"])[-1] if eligible else None


def check(status, label, value=None, evidence="", **extra):
    return {"status": status, "label": label, "value": value, "evidence": evidence, **extra}


def choose_report(rows, end_date):
    candidates = [row for row in rows if str(row.get("end_date")) == end_date and str(row.get("ann_date") or "99999999") <= AS_OF]
    if not candidates:
        return None
    preferred = [row for row in candidates if str(row.get("report_type") or "1") == "1"]
    candidates = preferred or candidates
    return sorted(candidates, key=lambda row: (str(row.get("ann_date") or ""), str(row.get("f_ann_date") or ""), str(row.get("update_flag") or "0")))[-1]


def numeric_check(value, label, rule, period=None, ann_date=None):
    status = "pass" if finite(value) and value > 0 else "fail" if finite(value) else "not_assessed"
    evidence = "数据缺失或无法按截止日确认" if status == "not_assessed" else f"{value / 1e8:.2f} 亿元，{rule}"
    return check(status, label, value, evidence, period=period, ann_date=ann_date, rule=rule)


def financial_decision(code, refresh=False):
    fields_income = "ts_code,ann_date,f_ann_date,end_date,report_type,n_income_attr_p,update_flag"
    fields_cash = "ts_code,ann_date,f_ann_date,end_date,report_type,n_cashflow_act,update_flag"
    failures = []
    datasets = {}
    requests = [
        ("income", fields_income, {"ts_code": code, "start_date": PERIODS["query_start"], "end_date": AS_OF}),
        ("balancesheet", "ts_code,ann_date,f_ann_date,end_date,report_type,total_hldr_eqy_exc_min_int,update_flag", {"ts_code": code, "period": PERIODS["latest"]}),
        ("cashflow", fields_cash, {"ts_code": code, "start_date": PERIODS["query_start"], "end_date": AS_OF}),
        ("fina_audit", "ts_code,ann_date,end_date,audit_result,audit_agency", {"ts_code": code, "period": PERIODS["annual"]}),
    ]
    for api_name, fields, params in requests:
        try:
            datasets[api_name] = cached_call(api_name, fields, refresh=refresh, **params)
        except Exception as exc:
            datasets[api_name] = []
            failures.append({"stock_code": code, "stage": api_name, "reason": str(exc)[:500]})
    income = datasets["income"]
    cashflow = datasets["cashflow"]
    latest = choose_report(income, PERIODS["latest"])
    annual_row = choose_report(income, PERIODS["annual"])
    prior_latest = choose_report(income, PERIODS["latest_prior"])
    annual_prior_row = choose_report(income, PERIODS["annual_prior"])
    equity_row = choose_report(datasets["balancesheet"], PERIODS["latest"])
    ocf_row = choose_report(cashflow, PERIODS["annual"])
    ocf_prior_row = choose_report(cashflow, PERIODS["annual_prior"])
    audit_rows = [row for row in datasets["fina_audit"] if str(row.get("end_date")) == PERIODS["annual"] and str(row.get("ann_date") or "99999999") <= AS_OF]
    audit_row = sorted(audit_rows, key=lambda row: str(row.get("ann_date") or ""))[-1] if audit_rows else None
    latest_profit = as_float(latest.get("n_income_attr_p")) if latest else None
    profit_annual = as_float(annual_row.get("n_income_attr_p")) if annual_row else None
    profit_annual_prior = as_float(annual_prior_row.get("n_income_attr_p")) if annual_prior_row else None
    prior_latest_profit = as_float(prior_latest.get("n_income_attr_p")) if prior_latest else None
    ttm_profit = profit_annual + latest_profit - prior_latest_profit if all(finite(value) for value in (profit_annual, latest_profit, prior_latest_profit)) else None
    equity = as_float(equity_row.get("total_hldr_eqy_exc_min_int")) if equity_row else None
    cash_annual = as_float(ocf_row.get("n_cashflow_act")) if ocf_row else None
    cash_annual_prior = as_float(ocf_prior_row.get("n_cashflow_act")) if ocf_prior_row else None
    audit = str(audit_row.get("audit_result") or "").strip() if audit_row else None
    annual_year = PERIODS["annual"][:4]
    prior_year = PERIODS["annual_prior"][:4]
    ttm_formula = f"{PERIODS['annual']}年报归母净利润+{PERIODS['latest']}累计归母净利润-{PERIODS['latest_prior']}累计归母净利润"
    checks = {
        "latest_profit": numeric_check(latest_profit, "最新归母净利润", f"{PERIODS['latest']}累计值须为正", PERIODS["latest"], latest.get("ann_date") if latest else None),
        "ttm_profit": numeric_check(ttm_profit, "TTM归母净利润", f"{ttm_formula}，须为正", f"TTM至{PERIODS['latest']}", latest.get("ann_date") if latest else None),
        "equity": numeric_check(equity, "归母净资产", f"{PERIODS['latest']}归母权益须为正", PERIODS["latest"], equity_row.get("ann_date") if equity_row else None),
        "two_year_loss": check(
            "fail" if finite(profit_annual) and finite(profit_annual_prior) and profit_annual < 0 and profit_annual_prior < 0 else "pass" if finite(profit_annual) and finite(profit_annual_prior) else "not_assessed",
            "最近两个年度不连续亏损",
            {prior_year: profit_annual_prior, annual_year: profit_annual},
            f"{prior_year}、{annual_year}年报归母净利润均为负则不通过" if finite(profit_annual) and finite(profit_annual_prior) else "年度利润数据未完整取得",
            periods=[PERIODS["annual_prior"], PERIODS["annual"]],
        ),
        "ocf": check(
            "fail" if finite(cash_annual) and finite(cash_annual_prior) and cash_annual < 0 and cash_annual_prior < 0 else "pass" if finite(cash_annual) and finite(cash_annual_prior) else "not_assessed",
            "经营现金流未连续两年为负",
            {prior_year: cash_annual_prior, annual_year: cash_annual},
            f"{prior_year}、{annual_year}年度经营现金流均为负则不通过" if finite(cash_annual) and finite(cash_annual_prior) else "年度经营现金流数据未完整取得",
            periods=[PERIODS["annual_prior"], PERIODS["annual"]],
        ),
        "audit": check(
            "pass" if audit in ("标准无保留意见", "无保留意见") else "fail" if audit else "not_assessed",
            "标准无保留审计意见",
            audit,
            audit or f"{annual_year}年度审计意见未取得",
            period=PERIODS["annual"],
            ann_date=audit_row.get("ann_date") if audit_row else None,
        ),
    }
    statuses = [item["status"] for item in checks.values()]
    result = "fail" if "fail" in statuses else "not_assessed" if "not_assessed" in statuses else "pass"
    return {
        "latest_report_period": PERIODS["latest"],
        "annual_periods": [PERIODS["annual_prior"], PERIODS["annual"]],
        "latest_announcement_date": latest.get("ann_date") if latest else None,
        "latest_profit": latest_profit,
        "ttm_profit": ttm_profit,
        "ttm_formula": ttm_formula,
        "equity": equity,
        "profit_annual": profit_annual,
        "profit_annual_prior": profit_annual_prior,
        "ocf_annual": cash_annual,
        "ocf_annual_prior": cash_annual_prior,
        "profit_2025": profit_annual,
        "profit_2024": profit_annual_prior,
        "ocf_2025": cash_annual,
        "ocf_2024": cash_annual_prior,
        "audit_opinion": audit,
        "financial_checks": checks,
        "financial_result": result,
        "financial_source": "Tushare Pro income/balancesheet/cashflow/fina_audit",
        "financial_failures": failures,
    }


def build_pool(local, rankings, refresh=False):
    market = json.loads((OUTPUT / "market-state.json").read_text(encoding="utf-8"))
    style = STYLE_CONFIG.get(market.get("market_state"), STYLE_CONFIG["defense"])
    selected = sorted(rankings["industry_rankings"], key=lambda row: row[style["rank"]])[:5]
    guidance = as_float(market.get("guidance_position_pct")) or 0
    score_sum = sum(row[style["score"]] for row in selected)
    for row in selected:
        row["industry_guidance_position_pct"] = guidance * row[style["score"]] / score_sum if score_sum else None
        row["selected_style"] = style["label"]
        row["selected_style_rank"] = row[style["rank"]]
        row["selected_style_score"] = row[style["score"]]
    constituents = []
    for industry in selected:
        members = cached_call(
            "index_member_all",
            "l1_code,l1_name,ts_code,name,in_date,out_date,is_new",
            refresh=refresh,
            l1_code=industry["industry_code"],
            is_new="Y",
        )
        print(f"{industry['industry_name']}成分股：{len(members)} 只", flush=True)
        for member in members:
            code = member.get("ts_code")
            in_date = str(member.get("in_date") or "")
            out_date = str(member.get("out_date") or "")
            if (not in_date or in_date <= AS_OF) and (not out_date or out_date > AS_OF) and re.fullmatch(r"\d{6}\.(SH|SZ)", str(code or "")):
                constituents.append({
                    "style": style["label"],
                    "industry_code": industry["industry_code"],
                    "industry_name": industry["industry_name"],
                    "industry_rank": industry[style["rank"]],
                    "industry_score": industry[style["score"]],
                    "industry_guidance_position_pct": industry["industry_guidance_position_pct"],
                    "stock_code": code,
                    "stock_name": member.get("name"),
                    "membership_in_date": member.get("in_date"),
                    "selection_reason": f"{style['label']}风格第{industry[style['rank']]}名行业全部成分股",
                })
    constituents = sorted(constituents, key=lambda row: (row["industry_rank"], row["stock_code"]))
    basic_rows = []
    new_stock_histories = {}
    for position, base in enumerate(constituents, start=1):
        code = base["stock_code"]
        master = local["master"].get(code, {})
        name = str(master.get("name") or base["stock_name"] or "")
        list_date = str(master.get("list_date") or "")
        listing_days = (datetime.strptime(AS_OF, "%Y%m%d").date() - datetime.strptime(list_date, "%Y%m%d").date()).days if re.fullmatch(r"\d{8}", list_date) else None
        history = sorted(local["stocks"].get(code, []), key=lambda row: row["trade_date"])
        observed_days = len({row["trade_date"] for row in history if row["trade_date"] <= AS_OF})
        completed_trading_days = observed_days if listing_days is not None and listing_days < 180 else None
        if listing_days is not None and listing_days < 180:
            try:
                if code not in new_stock_histories:
                    new_stock_histories[code] = cached_call("daily", "ts_code,trade_date,close,amount", refresh=refresh, ts_code=code, start_date=list_date, end_date=AS_OF)
                completed_trading_days = len({row["trade_date"] for row in new_stock_histories[code] if row["trade_date"] <= AS_OF})
            except Exception:
                completed_trading_days = None
        listing_status = "pass" if (listing_days is not None and listing_days >= 180) or (completed_trading_days is not None and completed_trading_days >= 120) else "fail" if listing_days is not None and completed_trading_days is not None else "not_assessed"
        current_st = latest_row(local["st"].get(code, []))
        current_st = current_st if current_st and current_st.get("trade_date") == AS_OF else None
        risk_text = " ".join(filter(None, [name, str(current_st.get("type_name") if current_st else ""), str(current_st.get("type") if current_st else "")]))
        risk_flag = bool(re.search(r"(?i)(\*?ST|退市|终止上市|风险警示)", risk_text))
        risk_status = "fail" if risk_flag else "pass" if master else "not_assessed"
        quote = latest_row(history)
        quote = quote if quote and quote.get("trade_date") == AS_OF else None
        suspension = latest_row(local["suspensions"].get(code, []))
        suspended = bool(suspension and suspension.get("trade_date") == AS_OF and suspension.get("suspend_type") == "S")
        limit = latest_row(local["limits"].get(code, []))
        limit = limit if limit and limit.get("trade_date") == AS_OF else None
        close = as_float(quote.get("close")) if quote else None
        upper_limit = as_float(limit.get("up_limit")) if limit else None
        at_upper_limit = finite(close) and finite(upper_limit) and close >= upper_limit - 0.0001
        trading_status = "fail" if suspended or at_upper_limit else "pass" if quote and limit else "not_assessed"
        amounts = [as_float(row.get("amount")) * 1000 for row in history[-20:] if as_float(row.get("amount")) is not None]
        average20 = statistics.fmean(amounts) if len(amounts) >= 20 else None
        liquidity_status = "pass" if finite(average20) and average20 >= LIQUIDITY_THRESHOLD_CNY else "fail" if finite(average20) else "not_assessed"
        basic_checks = {
            "listing_age": check(listing_status, "上市时间", {"calendar_days": listing_days, "completed_trading_days": completed_trading_days}, "至少180个自然日或120个完整交易日", list_date=list_date),
            "risk": check(risk_status, "风险警示", current_st.get("type_name") if current_st else name, "剔除ST、*ST、退市整理及明确终止上市风险"),
            "trading": check(trading_status, "交易与买入价格", {"close": close, "upper_limit": upper_limit, "suspended": suspended}, "剔除停牌及买入方向涨停；跌停不自动剔除", quote_date=AS_OF, limit_source="Tushare stk_limit快照"),
            "liquidity": check(liquidity_status, "20日平均成交额", average20, f"{average20 / 1e6:.2f} 百万元，门槛30百万元" if finite(average20) else "完整20日成交额不足", threshold_cny=LIQUIDITY_THRESHOLD_CNY),
        }
        statuses = [item["status"] for item in basic_checks.values()]
        basic_result = "fail" if "fail" in statuses else "not_assessed" if "not_assessed" in statuses else "pass"
        basic_rows.append({
            **base,
            "stock_name": name,
            "evaluation_date": TRADE_DATE,
            "list_date": list_date,
            "listing_calendar_days": listing_days,
            "completed_trading_days": completed_trading_days,
            "close": close,
            "upper_limit": upper_limit,
            "average20_amount_cny": average20,
            "basic_checks": basic_checks,
            "basic_result": basic_result,
            "basic_source": "Tushare快照：daily/stock_basic/namechange/suspend_d/stk_limit",
            "event_risk_status": "not_applicable",
            "final_tradable": "no" if basic_result == "fail" else "needs_review",
        })
        if position % 50 == 0:
            print(f"基础过滤进度：{position}/{len(constituents)}", flush=True)
    for industry_code in {row["industry_code"] for row in basic_rows}:
        peers = [row for row in basic_rows if row["industry_code"] == industry_code]
        for rank, row in enumerate(sorted(peers, key=lambda row: (-(row["average20_amount_cny"] or -1), row["stock_code"])), start=1):
            row["liquidity_rank_in_industry"] = rank
    financial_rows = []
    eligible_rows = []
    excluded_rows = []
    all_failures = []
    basic_pass = [row for row in basic_rows if row["basic_result"] == "pass"]
    for position, basic in enumerate(basic_pass, start=1):
        print(f"财务过滤 {position}/{len(basic_pass)}：{basic['stock_code']} {basic['stock_name']}", flush=True)
        financial = financial_decision(basic["stock_code"], refresh=refresh)
        row = {
            **basic,
            **financial,
            "candidate_scope": f"{style['label']}前五行业全部成分股（财务筛选前无Top-N截断）",
            "event_risk_status": "not_assessed",
            "event_review_source": "CNINFO/交易所公告尚未逐股复核",
            "final_tradable": "no" if financial["financial_result"] == "fail" else "needs_event_review" if financial["financial_result"] == "pass" else "needs_review",
            "stock_pool_status": "待事件复核" if financial["financial_result"] == "pass" else "财务不通过" if financial["financial_result"] == "fail" else "财务待复核",
        }
        financial_rows.append(row)
        all_failures.extend(financial["financial_failures"])
        if financial["financial_result"] == "pass":
            eligible_rows.append(row)
    for row in basic_rows:
        if row["basic_result"] != "pass":
            failed = [item["label"] + ("未评估" if item["status"] == "not_assessed" else "不通过") for item in row["basic_checks"].values() if item["status"] != "pass"]
            excluded_rows.append({**row, "exclusion_stage": "基础交易过滤", "exclusion_reason": "；".join(failed)})
    for row in financial_rows:
        if row["financial_result"] != "pass":
            failed = [item["label"] + ("未评估" if item["status"] == "not_assessed" else "不通过") for item in row["financial_checks"].values() if item["status"] != "pass"]
            excluded_rows.append({**row, "exclusion_stage": "财务硬过滤", "exclusion_reason": "；".join(failed)})
    counts = {
        "selected_industries": len(selected),
        "all_constituents": len(basic_rows),
        "basic_pass": len(basic_pass),
        "basic_fail_or_unassessed": len(basic_rows) - len(basic_pass),
        "financial_assessed": len(financial_rows),
        "financial_pass": len(eligible_rows),
        "financial_fail_or_unassessed": len(financial_rows) - len(eligible_rows),
        "eligible_pool": len(eligible_rows),
        "excluded": len(excluded_rows),
        "final_tradable_yes": 0,
        "needs_event_review": len(eligible_rows),
    }
    payload = {
        "metadata": {
            "schema_version": "1.0",
            "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "trade_date": TRADE_DATE,
            "evaluation_timestamp": EVALUATION_TIMESTAMP,
            "selected_style": style["label"],
            "classification": "申万2021一级行业",
            "classification_snapshot_date": TRADE_DATE,
            "candidate_scope": f"{style['label']}前五行业全部成分股，基础过滤后不截断，逐股财务评估",
            "liquidity_threshold_cny": LIQUIDITY_THRESHOLD_CNY,
            "listing_age_days": 180,
            "listing_trading_days": 120,
            "exclude_limit_down": False,
            "official_event_review": "not_completed",
            "financial_period": PERIODS["latest"],
            "annual_periods": [PERIODS["annual_prior"], PERIODS["annual"]],
            "ttm_formula": f"{PERIODS['annual']}年报+{PERIODS['latest']}-{PERIODS['latest_prior']}",
            "point_in_time_rule": f"仅采用公告日期不晚于{AS_OF}的报告",
            "data_sources": ["Tushare Pro", f"状态机实算{AS_OF}行情快照"],
        },
        "counts": counts,
        "selected_industries": selected,
        "basic_rows": basic_rows,
        "financial_rows": financial_rows,
        "eligible_rows": eligible_rows,
        "excluded_rows": excluded_rows,
        "failures": all_failures + [{
            "stage": "官方事件核验",
            "source": "CNINFO/上交所/深交所",
            "identifier": "财务合格池全部股票",
            "reason": "尚未逐股完成官方公告检索与内容复核，不能标记final_tradable=yes",
            "fallback": "保留为needs_event_review",
        }],
    }
    write_json(OUTPUT / "stock-pool-current.json", payload)
    print("股票池计数：" + json.dumps(counts, ensure_ascii=False), flush=True)
    return payload


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--refresh", action="store_true")
    parser.add_argument("--rankings-only", action="store_true")
    parser.add_argument("--pool-only", action="store_true")
    args = parser.parse_args()
    local = load_local_cache()
    if args.pool_only:
        rankings = json.loads((OUTPUT / "industry-rankings.json").read_text(encoding="utf-8"))
    else:
        rankings = calculate_rankings(local, refresh=args.refresh)
    if not args.rankings_only:
        pool = build_pool(local, rankings, refresh=args.refresh)
        summary = {"trade_date": TRADE_DATE, "industry_counts": rankings["counts"], "pool_counts": pool["counts"], "selected_industries": [{"code": row["industry_code"], "name": row["industry_name"], "score": row["defensive_score"]} for row in pool["selected_industries"]], "financial_failures": len(pool["failures"]) - 1}
        write_json(ROOT / "enrichment-summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
