import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { config, assertLiveConfig } from "./config.js";

const API_URL = "https://api.tushare.pro";

function sleep(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function responseToRows(payload) {
  const fields = payload?.data?.fields || [];
  const items = payload?.data?.items || [];
  return items.map((item) =>
    Object.fromEntries(fields.map((field, index) => [field, item[index]])),
  );
}

function cacheKey(apiName, params) {
  return crypto
    .createHash("sha1")
    .update(JSON.stringify({ apiName, params }))
    .digest("hex");
}

class RateLimiter {
  constructor(requestsPerMinute) {
    this.interval = Math.ceil(60_000 / requestsPerMinute);
    this.nextAt = 0;
    this.chain = Promise.resolve();
  }

  async acquire() {
    let release;
    const turn = new Promise((resolve) => {
      release = resolve;
    });
    const previous = this.chain;
    this.chain = previous.then(() => turn);
    await previous;
    const now = Date.now();
    const wait = Math.max(0, this.nextAt - now);
    this.nextAt = Math.max(now, this.nextAt) + this.interval;
    if (wait) await sleep(wait);
    release();
  }
}

export class TushareClient {
  constructor(options = {}) {
    this.token = options.token ?? config.token;
    this.timeoutMs = options.timeoutMs ?? config.requestTimeoutMs;
    this.cacheDir = options.cacheDir ?? path.join(config.dataDir, "cache");
    this.limiter = new RateLimiter(options.requestsPerMinute ?? config.requestsPerMinute);
    this.inflight = new Map();
  }

  async request(apiName, params = {}, fields = "", options = {}) {
    if (!this.token) assertLiveConfig();
    const key = cacheKey(apiName, params);
    const ttlMs = (options.ttlSeconds ?? 300) * 1000;
    const cacheFile = path.join(this.cacheDir, `${key}.json`);

    if (!options.refresh) {
      try {
        const stat = await fs.stat(cacheFile);
        if (Date.now() - stat.mtimeMs <= ttlMs) {
          return JSON.parse(await fs.readFile(cacheFile, "utf8"));
        }
      } catch {
        // Cache miss.
      }
    }

    if (this.inflight.has(key)) return this.inflight.get(key);

    const operation = this.#requestWithRetry(apiName, params, fields)
      .then(async (rows) => {
        if (options.persistCache !== false) {
          await fs.mkdir(this.cacheDir, { recursive: true });
          await fs.writeFile(cacheFile, JSON.stringify(rows), "utf8");
        }
        return rows;
      })
      .finally(() => this.inflight.delete(key));

    this.inflight.set(key, operation);
    return operation;
  }

  async #requestWithRetry(apiName, params, fields) {
    let lastError;
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      await this.limiter.acquire();
      try {
        const response = await fetch(API_URL, {
          method: "POST",
          headers: { "content-type": "application/json", accept: "application/json" },
          body: JSON.stringify({
            api_name: apiName,
            token: this.token,
            params,
            fields,
          }),
          signal: AbortSignal.timeout(this.timeoutMs),
        });
        if (!response.ok) {
          throw new Error(`Tushare HTTP ${response.status}`);
        }
        const payload = await response.json();
        if (payload.code !== 0) {
          const message = String(payload.msg || "unknown Tushare error");
          if (/权限|积分|permission|limit/i.test(message) && attempt === 3) {
            throw new Error(`${apiName}: ${message}`);
          }
          throw new Error(`${apiName}: ${message}`);
        }
        return responseToRows(payload);
      } catch (error) {
        lastError = error;
        if (attempt < 3) await sleep(700 * attempt);
      }
    }
    throw lastError;
  }
}
