import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const projectRoot = path.resolve(import.meta.dirname, "..");

function loadLocalEnv() {
  const file = path.join(projectRoot, ".env");
  if (!fs.existsSync(file)) return;
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator < 1) continue;
    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

loadLocalEnv();

function positiveNumber(name, fallback) {
  const parsed = Number(process.env[name]);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

export const config = {
  projectRoot,
  publicDir: path.join(projectRoot, "public"),
  defaultDataDir: path.join(projectRoot, "data"),
  port: positiveNumber("PORT", 8787),
  token: process.env.TUSHARE_TOKEN?.trim() || "",
  demoMode: process.env.DEMO_MODE === "1" || process.env.DEMO_MODE === "true",
  cacheMinutes: positiveNumber("REPORT_CACHE_MINUTES", 10),
  requestsPerMinute: positiveNumber("TUSHARE_REQUESTS_PER_MINUTE", 120),
  requestTimeoutMs: positiveNumber("TUSHARE_TIMEOUT_MS", 30_000),
  autoWarmup: process.env.AUTO_WARMUP !== "false",
  warmupYears: positiveNumber("WARMUP_YEARS", 5),
  dataDir: path.resolve(projectRoot, process.env.DATA_DIR || "./data"),
  nodeEnv: process.env.NODE_ENV || "development",
};

export function assertLiveConfig() {
  if (!config.token) {
    throw new Error("TUSHARE_TOKEN is not configured");
  }
}
