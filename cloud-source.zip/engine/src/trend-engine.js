import {
  clamp,
  ema,
  isFiniteNumber,
  maxDrawdown,
  mean,
  percentileRank,
} from "./math.js";

const HIGH_LOW_SCORES = {
  HH_HL: 100,
  HH_EL: 80,
  HH_LL: 45,
  EH_HL: 75,
  EH_EL: 50,
  EH_LL: 25,
  LH_HL: 55,
  LH_EL: 30,
  LH_LL: 0,
};

function finite(value) {
  return isFiniteNumber(value);
}

function atrWindow(rows, endIndex, window = 20) {
  if (endIndex < window) return null;
  const ranges = [];
  for (let index = endIndex - window + 1; index <= endIndex; index += 1) {
    const row = rows[index];
    const previousClose = rows[index - 1].close;
    ranges.push(
      Math.max(
        row.high - row.low,
        Math.abs(row.high - previousClose),
        Math.abs(row.low - previousClose),
      ),
    );
  }
  return mean(ranges);
}

function downsideVolatility(returns) {
  const clean = returns.filter(finite);
  if (!clean.length) return null;
  return Math.sqrt(
    252 * clean.reduce((total, value) => total + Math.min(value, 0) ** 2, 0) / clean.length,
  );
}

function scoreCondition(value, bullish, bearish) {
  if (!finite(value)) return null;
  if (value > bullish) return 1;
  if (value < bearish) return 0;
  return 0.5;
}

function highLowWindow(rows, endIndex, atr, window) {
  if (endIndex < 2 * window) return null;
  const tolerance = 0.3 * atr;
  const highNew = Math.max(
    ...rows.slice(endIndex - window + 1, endIndex + 1).map((row) => row.high),
  );
  const highOld = Math.max(
    ...rows.slice(endIndex - 2 * window + 1, endIndex - window + 1).map((row) => row.high),
  );
  const lowNew = Math.min(
    ...rows.slice(endIndex - window + 1, endIndex + 1).map((row) => row.low),
  );
  const lowOld = Math.min(
    ...rows.slice(endIndex - 2 * window + 1, endIndex - window + 1).map((row) => row.low),
  );
  const highState =
    highNew - highOld > tolerance ? "HH" : highNew - highOld < -tolerance ? "LH" : "EH";
  const lowState =
    lowNew - lowOld > tolerance ? "HL" : lowNew - lowOld < -tolerance ? "LL" : "EL";
  return {
    high_state: highState,
    low_state: lowState,
    score_100: HIGH_LOW_SCORES[`${highState}_${lowState}`],
  };
}

function t4State(closes, lows, ema20Values, ema60Values, atr20Values, index, slope20) {
  const lower20 = [];
  const upper20 = [];
  for (let cursor = index - 5; cursor <= index; cursor += 1) {
    lower20.push(ema20Values[cursor] - 0.3 * atr20Values[cursor]);
    upper20.push(ema20Values[cursor] + 0.3 * atr20Values[cursor]);
  }
  const lower60 = [];
  for (let cursor = index - 2; cursor <= index; cursor += 1) {
    lower60.push(ema60Values[cursor] - 0.3 * atr20Values[cursor]);
  }

  const fast20 = ema20Values[index - 1] - 0.8 * atr20Values[index - 1];
  const fast60 = ema60Values[index - 1] - 0.8 * atr20Values[index - 1];
  const ema60Break =
    (closes[index - 1] < lower60.at(-2) && closes[index] < lower60.at(-1)) ||
    (closes[index - 1] < fast60 && closes[index] < lower60.at(-1));
  const ema20Break =
    (closes[index - 1] < lower20.at(-2) && closes[index] < lower20.at(-1)) ||
    (closes[index - 1] < fast20 && closes[index] < lower20.at(-1));
  const supportTouch = [index - 2, index - 1, index].some(
    (cursor) =>
      lows[cursor] <= ema20Values[cursor] + 0.3 * atr20Values[cursor] &&
      closes[cursor] >= ema20Values[cursor] - 0.8 * atr20Values[cursor],
  );
  const twoBelow = [index - 2, index - 1, index].some(
    (cursor) =>
      closes[cursor - 1] < ema20Values[cursor - 1] - 0.3 * atr20Values[cursor - 1] &&
      closes[cursor] < ema20Values[cursor] - 0.3 * atr20Values[cursor],
  );
  const standFirm = supportTouch && closes[index] >= lower20.at(-1) && !twoBelow;
  const pullbackLow = Math.min(...lows.slice(index - 4, index + 1));
  const validPullback = standFirm && closes[index] >= pullbackLow + 0.8 * atr20Values[index];
  const repair =
    closes[index - 1] < ema20Values[index - 1] - 0.3 * atr20Values[index - 1] &&
    closes[index] >= ema20Values[index];
  const advance = closes[index] > upper20.at(-1) && slope20 > 0;

  if (ema60Break) return { state: "ema60_effective_break", score: 5 };
  if (ema20Break) return { state: "ema20_effective_break", score: 20 };
  if (validPullback) return { state: "valid_pullback", score: 85 };
  if (repair) return { state: "ema20_repair", score: 75 };
  if (standFirm) return { state: "pullback_held", score: 70 };
  if (advance) return { state: "advance", score: 65 };
  return { state: "neutral_transition", score: 50 };
}

function calculateT7(rows, atr20Values, index) {
  const closes = rows.map((row) => row.close);
  let event = null;
  for (let cursor = Math.max(20, index - 3); cursor <= index; cursor += 1) {
    const upper = Math.max(...rows.slice(cursor - 20, cursor).map((row) => row.high));
    const lower = Math.min(...rows.slice(cursor - 20, cursor).map((row) => row.low));
    if (closes[cursor] > upper + 0.2 * atr20Values[cursor]) {
      event = { direction: "up", index: cursor, boundary: upper, atr: atr20Values[cursor] };
    } else if (closes[cursor] < lower - 0.2 * atr20Values[cursor]) {
      event = { direction: "down", index: cursor, boundary: lower, atr: atr20Values[cursor] };
    }
  }

  const high = rows[index].high;
  const low = rows[index].low;
  const clv = high > low ? (closes[index] - low - (high - closes[index])) / (high - low) : 0;
  if (!event) {
    return {
      score: 1,
      state: "no_key_event",
      event_date: null,
      s_state: 0,
      clv,
      phase_permission: "normal",
    };
  }

  const laterCloses = closes.slice(event.index + 1, index + 1);
  let state;
  let sState;
  if (event.index === index) {
    state = `${event.direction}_break_pending`;
    sState = event.direction === "up" ? 0.35 : -0.35;
  } else if (event.direction === "up") {
    const held = laterCloses.every((close) => close >= event.boundary - 0.1 * event.atr);
    if (!held) [state, sState] = ["up_break_failed", -0.5];
    else if (closes[index] >= event.boundary + 0.8 * event.atr) [state, sState] = ["up_extension", 1];
    else [state, sState] = ["up_held", 0.75];
  } else {
    const held = laterCloses.every((close) => close <= event.boundary + 0.1 * event.atr);
    if (!held) [state, sState] = ["down_break_failed", 0.5];
    else if (closes[index] <= event.boundary - 0.8 * event.atr) [state, sState] = ["down_extension", -1];
    else [state, sState] = ["down_held", -0.75];
  }
  const score = 1 + clamp(sState + 0.15 * clv, -1, 1);
  return {
    score,
    state,
    event_date: rows[event.index].trade_date,
    s_state: sState,
    clv,
    phase_permission: score <= 0.6 ? "pause_attack" : "normal",
  };
}

export function calculateIndexAt(rows, index = rows.length - 1) {
  if (rows.length < 260 || index < 220) {
    throw new Error("核心指数历史不足，至少需要 260 个交易日");
  }

  const slice = rows.slice(0, index + 1);
  const closes = slice.map((row) => row.close);
  const opens = slice.map((row) => row.open);
  const highs = slice.map((row) => row.high);
  const lows = slice.map((row) => row.low);
  const returns = [null];
  const trueRanges = [null];

  for (let cursor = 1; cursor < slice.length; cursor += 1) {
    returns.push(closes[cursor] / closes[cursor - 1] - 1);
    trueRanges.push(
      Math.max(
        highs[cursor] - lows[cursor],
        Math.abs(highs[cursor] - closes[cursor - 1]),
        Math.abs(lows[cursor] - closes[cursor - 1]),
      ),
    );
  }

  const atr20Values = trueRanges.map((_, cursor) => atrWindow(slice, cursor));
  const ema20Values = ema(closes, 20);
  const ema60Values = ema(closes, 60);
  const atr20Ema = ema(trueRanges.map((value) => value ?? 0), 20);
  const d20 = [];
  const d40 = [];
  const downside20 = [];
  const downside5 = [];
  const mdd20 = [];
  const mdd5 = [];
  const r3 = [];
  const r5 = [];
  const r20 = [];
  const acceleration5 = [];
  const atrRatio = [];
  const maDistanceChange = [];

  for (let cursor = 0; cursor < slice.length; cursor += 1) {
    const atr = atr20Values[cursor];
    d20.push(cursor >= 20 && atr ? (closes[cursor] - closes[cursor - 20]) / atr : null);
    d40.push(cursor >= 40 && atr ? (closes[cursor] - closes[cursor - 40]) / atr : null);
    downside20.push(cursor >= 19 ? downsideVolatility(returns.slice(cursor - 19, cursor + 1)) : null);
    mdd20.push(cursor >= 19 ? maxDrawdown(closes.slice(cursor - 19, cursor + 1)) : null);
    downside5.push(cursor >= 4 ? downsideVolatility(returns.slice(cursor - 4, cursor + 1)) : null);
    mdd5.push(cursor >= 4 ? maxDrawdown(closes.slice(cursor - 4, cursor + 1)) : null);
    r3.push(cursor >= 3 ? closes[cursor] / closes[cursor - 3] - 1 : null);
    r5.push(cursor >= 5 ? closes[cursor] / closes[cursor - 5] - 1 : null);
    r20.push(cursor >= 20 ? closes[cursor] / closes[cursor - 20] - 1 : null);
    acceleration5.push(
      finite(r5[cursor]) && finite(r20[cursor]) ? r5[cursor] - 0.25 * r20[cursor] : null,
    );
    atrRatio.push(atr20Ema[cursor] ? atr20Ema[cursor] / closes[cursor] : null);
    if (cursor >= 5 && atr20Values[cursor] && atr20Values[cursor - 5]) {
      const currentDistance = (closes[cursor] - ema20Values[cursor]) / atr20Values[cursor];
      const previousDistance =
        (closes[cursor - 5] - ema20Values[cursor - 5]) / atr20Values[cursor - 5];
      maDistanceChange.push(currentDistance - previousDistance);
    } else {
      maDistanceChange.push(null);
    }
  }

  const current = slice.length - 1;
  const qDirection =
    100 *
    (0.6 * percentileRank(d20, d20[current]) + 0.4 * percentileRank(d40, d40[current]));
  const qPath =
    100 *
    (0.5 * (1 - percentileRank(downside20, downside20[current])) +
      0.5 * (1 - percentileRank(mdd20, mdd20[current])));
  const kPath = 0.7 + 0.3 * (qPath / 100);
  const qT1 = 50 + kPath * (qDirection - 50);
  const t1 = (6 * qT1) / 100;
  const dPrice = 0.6 * d20[current] + 0.4 * d40[current];

  const qMomentum =
    100 *
    (0.4 * percentileRank(r3, r3[current]) +
      0.4 * percentileRank(r5, r5[current]) +
      0.2 * percentileRank(acceleration5, acceleration5[current]));
  const qShortPath =
    100 *
    (0.5 * (1 - percentileRank(downside5, downside5[current])) +
      0.5 * (1 - percentileRank(mdd5, mdd5[current])));
  const kShort = 0.7 + 0.3 * (qShortPath / 100);
  const qT2 = 50 + kShort * (qMomentum - 50);
  const t2 = (5 * qT2) / 100;

  const atr = atr20Values[current];
  const slope20 = (ema20Values[current] - ema20Values[current - 5]) / (5 * atr);
  const slope60 = (ema60Values[current] - ema60Values[current - 5]) / (5 * atr);
  const t3Conditions = [
    scoreCondition((closes[current] - ema20Values[current]) / atr, 0.2, -0.2),
    scoreCondition(slope20, 0.03, -0.03),
    scoreCondition((closes[current] - ema60Values[current]) / atr, 0.2, -0.2),
    scoreCondition(slope60, 0.02, -0.02),
    scoreCondition((ema20Values[current] - ema60Values[current]) / atr, 0.2, -0.2),
  ];
  const t3Raw = t3Conditions.reduce((total, value) => total + value, 0);

  let crossingCount = 0;
  let previousSign = 0;
  for (let cursor = current - 19; cursor <= current; cursor += 1) {
    const difference = closes[cursor] - ema20Values[cursor];
    const sign = difference > 0 ? 1 : difference < 0 ? -1 : previousSign;
    if (previousSign && sign !== previousSign) crossingCount += 1;
    previousSign = sign;
  }
  const crossingPressure = clamp(crossingCount / 4, 0, 1);
  const displacementDeficiency = 1 - clamp(Math.abs(d20[current]) / 0.8, 0, 1);
  const bonded =
    1 - clamp(Math.abs(ema20Values[current] - ema60Values[current]) / (0.2 * atr), 0, 1);
  const slopeDead =
    0.5 *
    (1 -
      clamp(Math.abs(slope20) / 0.03, 0, 1) +
      (1 - clamp(Math.abs(slope60) / 0.02, 0, 1)));
  const congestion = Math.max(crossingPressure * displacementDeficiency, bonded * slopeDead);
  const pCongestion = 1 - 0.65 * congestion;
  const t3 = 2.5 + pCongestion * (t3Raw - 2.5);
  const frequentCrossing = crossingCount >= 4 && Math.abs(d20[current]) < 0.8;
  const t3Vote = frequentCrossing ? "neutral" : t3Raw >= 3.5 ? "up" : t3Raw <= 1.5 ? "down" : "neutral";

  const qMaDistance =
    100 * percentileRank(maDistanceChange, maDistanceChange[current]);
  const t4 = t4State(
    closes,
    lows,
    ema20Values,
    ema60Values,
    atr20Values,
    current,
    slope20,
  );
  const qT4Base = 0.45 * qMaDistance + 0.55 * t4.score;
  const qT4 = 50 + pCongestion * (qT4Base - 50);
  const t4Score = (3 * qT4) / 100;

  const zValues = [];
  const efficiencyDetails = {};
  for (const window of [10, 20]) {
    const path = Array.from({ length: window }, (_, offset) =>
      Math.abs(closes[current - offset] - closes[current - offset - 1]),
    ).reduce((total, value) => total + value, 0);
    const efficiency = path
      ? (closes[current] - closes[current - window]) / path
      : 0;
    const direction =
      closes[current] > closes[current - window]
        ? 1
        : closes[current] < closes[current - window]
          ? -1
          : 0;
    const sameDirection = direction
      ? Array.from({ length: window }, (_, offset) => {
          const cursor = current - offset;
          return (closes[cursor] - closes[cursor - 1]) * direction > 0;
        }).filter(Boolean).length
      : 0;
    const participation = sameDirection / window;
    const participationFactor = clamp((participation - 0.3) / 0.25, 0, 1);
    const displacement = Math.abs(closes[current] - closes[current - window]) / atr;
    const displacementFactor = clamp((displacement - 0.5) / 1, 0, 1);
    const z = efficiency * participationFactor * displacementFactor;
    zValues.push(z);
    efficiencyDetails[window] = {
      efficiency,
      same_direction_participation: participation,
      displacement_atr: displacement,
      z,
    };
  }
  const zStar = 0.4 * zValues[0] + 0.6 * zValues[1];
  const t5 = 2 * (1 + zStar);
  const t6Window10 = highLowWindow(slice, current, atr, 10);
  const t6Window20 = highLowWindow(slice, current, atr, 20);
  const qT6 = 0.4 * t6Window10.score_100 + 0.6 * t6Window20.score_100;
  const t6 = (5 * qT6) / 100;
  const t6Vote = qT6 >= 65 ? "up" : qT6 <= 35 ? "down" : "neutral";
  const t7 = calculateT7(slice, atr20Values, current);

  const zGap = (opens[current] - closes[current - 1]) / atr;
  const zClose = (closes[current] - closes[current - 1]) / atr;
  const zLow = (lows[current] - closes[current - 1]) / atr;
  const yellow = zClose <= -0.8 || zGap <= -0.6 || zLow <= -1.2;
  const red = zClose <= -1.5 || zLow <= -2 || (zGap <= -1 && zClose <= -1);

  const pctDownside = percentileRank(downside20.slice(0, -1), downside20[current]);
  const pctDrawdown = percentileRank(mdd20.slice(0, -1), mdd20[current]);
  const rawD3 = 3 * (1 - percentileRank(atrRatio.slice(0, -1), atrRatio[current]));
  const previousRawD3 = 3 * (1 - percentileRank(atrRatio.slice(0, -2), atrRatio[current - 1]));
  const d3 = (2 * rawD3 + previousRawD3) / 3;
  const e4State =
    closes[current] > ema20Values[current] && ema20Values[current] > ema20Values[current - 5]
      ? 1
      : closes[current] < ema20Values[current] && ema20Values[current] < ema20Values[current - 5]
        ? -1
        : 0;

  return {
    trade_date: slice[current].trade_date,
    close: closes[current],
    change_pct: returns[current] * 100,
    atr20: atr,
    T1: {
      score: t1,
      q_direction: qDirection,
      q_path: qPath,
      d20_atr: d20[current],
      d40_atr: d40[current],
      d_price: dPrice,
      vote: dPrice >= 0.8 ? "up" : dPrice <= -0.8 ? "down" : "neutral",
    },
    T2: {
      score: t2,
      q_momentum: qMomentum,
      q_short_path: qShortPath,
      r3_pct: r3[current] * 100,
      r5_pct: r5[current] * 100,
      acceleration5_pct: acceleration5[current] * 100,
    },
    T3: {
      score: t3,
      raw: t3Raw,
      conditions: t3Conditions,
      vote: t3Vote,
      crossing_count_20d: crossingCount,
      p_congestion: pCongestion,
    },
    T4: {
      score: t4Score,
      state: t4.state,
      q_ma_distance_change: qMaDistance,
      q_pullback_repair: t4.score,
    },
    T5: {
      score: t5,
      z_star: zStar,
      details: efficiencyDetails,
    },
    T6: {
      score: t6,
      q_t6: qT6,
      vote: t6Vote,
      window10: t6Window10,
      window20: t6Window20,
    },
    T7: t7,
    risk: {
      z_gap: zGap,
      z_close: zClose,
      z_low: zLow,
      yellow,
      red,
    },
    downside: {
      d1: 4 * (1 - pctDownside),
      d2: 4 * (1 - pctDrawdown),
      d3,
      pct_downside: pctDownside,
      pct_drawdown: pctDrawdown,
    },
    E4_state: e4State,
  };
}

function riskSnapshot(details) {
  const yellowCount = details.filter((item) => item.risk.yellow).length;
  const redCount = details.filter((item) => item.risk.red).length;
  const averageClose = mean(details.map((item) => item.risk.z_close));
  const averageGap = mean(details.map((item) => item.risk.z_gap));
  const level =
    redCount >= 2 || averageClose <= -1.5 || (averageGap <= -1 && averageClose <= -1)
      ? "R2"
      : yellowCount >= 2 || redCount >= 1
        ? "R1"
        : "R0";
  return {
    level,
    yellow_count: yellowCount,
    red_count: redCount,
    average_z_close: averageClose,
    average_z_gap: averageGap,
  };
}

function applyRiskHysteresis(current, previousSnapshot, previousOverlay) {
  if (current.level === "R2") {
    return {
      level: "R2",
      reason: "两个及以上指数触发红色风险，或三指数平均跌幅达到 R2 阈值",
      extreme_risk_overlay: true,
      release_counter: 0,
    };
  }
  if (current.level === "R1") {
    return {
      level: "R1",
      reason: "两个及以上指数触发黄色风险，或任一指数触发红色风险",
      extreme_risk_overlay: false,
      release_counter: 0,
    };
  }
  if (previousOverlay?.level === "R2") {
    return {
      level: "R1",
      reason: "R2 条件消失，按滞后规则先降为 R1",
      extreme_risk_overlay: false,
      release_counter: 0,
    };
  }
  if (
    previousOverlay?.level === "R1" &&
    previousSnapshot?.level === "R0" &&
    current.average_z_close > -0.3
  ) {
    return {
      level: "R0",
      reason: "R1 条件连续两日消失，且三指数平均 Z_close 高于 -0.3",
      extreme_risk_overlay: false,
      release_counter: 2,
    };
  }
  if (previousOverlay?.level === "R1") {
    return {
      level: "R1",
      reason: "R1 解除需要两日确认，当前保留风险警告",
      extreme_risk_overlay: false,
      release_counter: (previousOverlay.release_counter || 0) + 1,
    };
  }
  return {
    level: "R0",
    reason: "三指数未触发 R1/R2 风险阈值",
    extreme_risk_overlay: false,
    release_counter: 0,
  };
}

export function calculateTrendModule(seriesByCode, previousReport = null) {
  const names = {
    "000001.SH": "上证指数",
    "399001.SZ": "深证成指",
    "399006.SZ": "创业板指",
  };
  const details = {};
  for (const [code, name] of Object.entries(names)) {
    const rows = seriesByCode[code];
    if (!rows?.length) throw new Error(`缺少 ${name} 日线`);
    details[name] = calculateIndexAt(rows, rows.length - 1);
  }

  const previousDetails = Object.fromEntries(
    Object.entries(names).map(([code, name]) => {
      const rows = seriesByCode[code];
      return [name, calculateIndexAt(rows, rows.length - 2)];
    }),
  );
  const latestDates = Object.values(details).map((item) => item.trade_date);
  if (new Set(latestDates).size !== 1) {
    throw new Error("三大指数最新交易日不一致");
  }

  const subitemNames = ["T1", "T2", "T3", "T4", "T5", "T6", "T7"];
  const subitems = Object.fromEntries(
    subitemNames.map((name) => {
      const max = { T1: 6, T2: 5, T3: 5, T4: 3, T5: 4, T6: 5, T7: 2 }[name];
      return [
        name,
        {
          score: mean(Object.values(details).map((item) => item[name].score)),
          max,
        },
      ];
    }),
  );
  const score = Object.values(subitems).reduce((total, item) => total + item.score, 0);

  const averageDPrice = mean(Object.values(details).map((item) => item.T1.d_price));
  const averageT3Raw = mean(Object.values(details).map((item) => item.T3.raw));
  const averageQT6 = mean(Object.values(details).map((item) => item.T6.q_t6));
  const votes = {
    T1: averageDPrice >= 0.8 ? "up" : averageDPrice <= -0.8 ? "down" : "neutral",
    T3: averageT3Raw >= 3.5 ? "up" : averageT3Raw <= 1.5 ? "down" : "neutral",
    T6: averageQT6 >= 65 ? "up" : averageQT6 <= 35 ? "down" : "neutral",
  };
  const candidate =
    Object.values(votes).filter((vote) => vote === "up").length >= 2
      ? "attack"
      : Object.values(votes).filter((vote) => vote === "down").length >= 2
        ? "defense"
        : "neutral";
  const previousAverageDPrice = mean(
    Object.values(previousDetails).map((item) => item.T1.d_price),
  );
  const previousAverageT3Raw = mean(
    Object.values(previousDetails).map((item) => item.T3.raw),
  );
  const previousAverageQT6 = mean(
    Object.values(previousDetails).map((item) => item.T6.q_t6),
  );
  const previousVotes = {
    T1: previousAverageDPrice >= 0.8 ? "up" : previousAverageDPrice <= -0.8 ? "down" : "neutral",
    T3: previousAverageT3Raw >= 3.5 ? "up" : previousAverageT3Raw <= 1.5 ? "down" : "neutral",
    T6: previousAverageQT6 >= 65 ? "up" : previousAverageQT6 <= 35 ? "down" : "neutral",
  };
  const previousCandidate =
    Object.values(previousVotes).filter((vote) => vote === "up").length >= 2
      ? "attack"
      : Object.values(previousVotes).filter((vote) => vote === "down").length >= 2
        ? "defense"
        : "neutral";
  const confirmed = candidate === previousCandidate && candidate !== "neutral";
  const structuralState = confirmed ? candidate : "neutral";

  const riskCurrentRaw = riskSnapshot(Object.values(details));
  const riskPreviousRaw = riskSnapshot(Object.values(previousDetails));
  const overlay = applyRiskHysteresis(
    riskCurrentRaw,
    riskPreviousRaw,
    previousReport?.risk_overlay,
  );

  const indexD = Object.fromEntries(
    Object.entries(details).map(([name, item]) => [
      name,
      {
        d1: item.downside.d1,
        d2: item.downside.d2,
        d3: item.downside.d3,
        pct_downside: item.downside.pct_downside,
        pct_drawdown: item.downside.pct_drawdown,
      },
    ]),
  );

  return {
    trade_date: latestDates[0],
    module: {
      score,
      max: 30,
      status: "complete",
      version: "A-trend-state-v1.2.1",
      subitems,
      index_details: details,
      structural: {
        votes,
        raw_candidate: candidate,
        previous_raw_candidate: previousCandidate,
        average_d_price: averageDPrice,
        average_t3_raw: averageT3Raw,
        average_q_t6: averageQT6,
        state: structuralState,
        confirmation: confirmed ? "two_day_confirmed" : "pending",
      },
      t7_average: mean(Object.values(details).map((item) => item.T7.score)),
    },
    index_d: indexD,
    risk_overlay: {
      ...overlay,
      raw_current: riskCurrentRaw,
      raw_previous: riskPreviousRaw,
    },
  };
}

export function classifyRiskSnapshot(details) {
  return riskSnapshot(details);
}
