export const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

export const isFiniteNumber = (value) =>
  value !== null &&
  value !== undefined &&
  value !== "" &&
  Number.isFinite(Number(value));

export const numberOrNull = (value) => {
  if (!isFiniteNumber(value)) return null;
  return Number(value);
};

export function mean(values) {
  const clean = values.filter(isFiniteNumber).map(Number);
  return clean.length ? clean.reduce((sum, value) => sum + value, 0) / clean.length : null;
}

export function sum(values) {
  return values.filter(isFiniteNumber).reduce((total, value) => total + Number(value), 0);
}

export function quantile(values, probability) {
  const clean = values.filter(isFiniteNumber).map(Number).sort((a, b) => a - b);
  if (!clean.length) return null;
  const position = (clean.length - 1) * probability;
  const lower = Math.floor(position);
  const upper = Math.ceil(position);
  if (lower === upper) return clean[lower];
  const weight = position - lower;
  return clean[lower] * (1 - weight) + clean[upper] * weight;
}

export function percentileRank(values, current) {
  const clean = values.filter(isFiniteNumber).map(Number);
  if (!clean.length || !isFiniteNumber(current)) return null;
  return clean.filter((value) => value <= Number(current)).length / clean.length;
}

export function ema(values, window) {
  const alpha = 2 / (window + 1);
  let previous = null;
  return values.map((value) => {
    const current = numberOrNull(value);
    if (current === null) return previous;
    previous = previous === null ? current : alpha * current + (1 - alpha) * previous;
    return previous;
  });
}

export function maxDrawdown(closes) {
  if (!closes.length) return null;
  let peak = closes[0];
  let drawdown = 0;
  for (const close of closes) {
    peak = Math.max(peak, close);
    if (peak > 0) drawdown = Math.max(drawdown, 1 - close / peak);
  }
  return drawdown;
}

export function linearAnchors(value, anchors) {
  if (!isFiniteNumber(value)) return null;
  const points = [...anchors].sort((left, right) => left[0] - right[0]);
  if (value <= points[0][0]) return points[0][1];
  if (value >= points.at(-1)[0]) return points.at(-1)[1];
  for (let index = 0; index < points.length - 1; index += 1) {
    const [leftX, leftY] = points[index];
    const [rightX, rightY] = points[index + 1];
    if (value >= leftX && value <= rightX) {
      const weight = (value - leftX) / (rightX - leftX);
      return leftY + weight * (rightY - leftY);
    }
  }
  return null;
}

export function round(value, digits = 2) {
  if (!isFiniteNumber(value)) return null;
  const factor = 10 ** digits;
  return Math.round(Number(value) * factor) / factor;
}

export function dateString(date) {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Shanghai",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  return formatter.format(date);
}

export function compactDate(value) {
  return (value instanceof Date ? dateString(value) : String(value)).replaceAll("-", "");
}

export function addDays(value, days) {
  const date = value instanceof Date ? new Date(value) : new Date(`${value}T00:00:00+08:00`);
  date.setUTCDate(date.getUTCDate() + days);
  return date;
}

export function isSameDirection(change, direction) {
  return direction === 1 ? change > 0 : direction === -1 ? change < 0 : false;
}

export function averageOrNull(values) {
  return mean(values);
}

export function topShare(rows, amountKey, fraction) {
  const valid = rows.filter((row) => isFiniteNumber(row[amountKey]));
  if (!valid.length) return null;
  const total = sum(valid.map((row) => row[amountKey]));
  if (!total) return null;
  const count = Math.ceil(valid.length * fraction);
  const top = [...valid].sort((left, right) => right[amountKey] - left[amountKey]).slice(0, count);
  return sum(top.map((row) => row[amountKey])) / total;
}
