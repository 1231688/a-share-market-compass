import fs from "node:fs/promises";
import path from "node:path";
import { config } from "./config.js";
import {
  calculateBreadth,
  calculateEcology,
  calculateLiquidity,
  calculateRisk,
  calculateStructure,
  updateStateMachine,
} from "./market-modules.js";
import { calculateTrendModule } from "./trend-engine.js";
import {
  addDays,
  clamp,
  compactDate,
  dateString,
  isFiniteNumber,
  mean,
  round,
} from "./math.js";
import { TushareClient } from "./tushare.js";

const INDEX_DEFINITIONS = {
  "000001.SH": "上证指数",
  "399001.SZ": "深证成指",
  "399006.SZ": "创业板指",
};

const MODULE_NAMES = {
  A: "趋势状态",
  B: "市场广度",
  C: "成交与流动性",
  D: "波动与下行风险",
  E: "市场结构",
  F: "情绪与交易生态",
};

function numeric(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeDate(value) {
  const text = String(value || "").replaceAll("-", "");
  if (text.length !== 8) return String(value || "");
  return `${text.slice(0, 4)}-${text.slice(4, 6)}-${text.slice(6, 8)}`;
}

function normalizeIndexRows(rows) {
  return rows
    .map((row) => ({
      trade_date: normalizeDate(row.trade_date),
      open: numeric(row.open),
      high: numeric(row.high),
      low: numeric(row.low),
      close: numeric(row.close),
      volume: numeric(row.vol),
      amount: numeric(row.amount),
    }))
    .filter(
      (row) =>
        row.trade_date &&
        row.open !== null &&
        row.high !== null &&
        row.low !== null &&
        row.close !== null,
    )
    .sort((left, right) => left.trade_date.localeCompare(right.trade_date));
}

function normalizeDailyRows(rows) {
  return rows.map((row) => {
    const close = numeric(row.close);
    const preClose = numeric(row.pre_close);
    const reportedChange = numeric(row.pct_chg);
    return {
      ts_code: row.ts_code,
      trade_date: normalizeDate(row.trade_date),
      open: numeric(row.open),
      high: numeric(row.high),
      low: numeric(row.low),
      close,
      pre_close: preClose,
      pct_chg: reportedChange,
      pct_chg_ratio:
        reportedChange !== null
          ? reportedChange / 100
          : close !== null && preClose
            ? close / preClose - 1
            : null,
      amount_cny: numeric(row.amount) === null ? null : numeric(row.amount) * 1000,
    };
  });
}

function mapByCode(rows) {
  return new Map(rows.map((row) => [row.ts_code, row]));
}

function moduleRows(module) {
  if (!module || !isFiniteNumber(module.score)) return null;
  return round(module.score, 2);
}

function lineChartRows(rows, count = 120) {
  return rows.slice(-count).map((row) => ({
    date: row.trade_date,
    open: row.open,
    high: row.high,
    low: row.low,
    close: row.close,
  }));
}

function buildConfirmationsAndDivergences(modules) {
  const confirmations = [];
  const divergences = [];
  const structural = modules.A?.structural?.state;
  if (structural === "defense") confirmations.push("T1/T3/T6 结构投票确认防守趋势。");
  if (structural === "attack") confirmations.push("T1/T3/T6 结构投票确认进攻趋势。");
  if (modules.B?.score !== null && modules.B.score < 8) {
    confirmations.push("市场广度偏弱，个股参与度尚未确认普涨环境。");
  }
  if (modules.D?.score !== null && modules.D.score < 6) {
    confirmations.push("下行风险与波动安全得分偏低，路径风险仍高。");
  }
  if (
    modules.C?.subitems?.C1?.score >= 2 &&
    modules.C?.subitems?.C4?.score < 2
  ) {
    divergences.push("成交容量不低，但成交更集中在下跌一侧。");
  }
  if (
    modules.F?.score !== null &&
    modules.F.score >= 6 &&
    modules.B?.score !== null &&
    modules.B.score < 8
  ) {
    divergences.push("短线生态尚有热度，但市场广度不足，行情可能偏局部。");
  }
  if (
    modules.A?.structural?.state === "defense" &&
    modules.E?.score !== null &&
    modules.E.score >= 7
  ) {
    divergences.push("指数趋势偏防守，但行业组织度相对稳定，需观察是否形成止跌结构。");
  }
  if (!confirmations.length) confirmations.push("当前没有足够鲜明的同向模块确认。");
  if (!divergences.length) divergences.push("未发现足以推翻当前状态判断的跨模块强背离。");
  return { confirmations, divergences };
}

function moduleDrivers(modules) {
  return {
    A: modules.A
      ? `结构${modules.A.structural.state === "attack" ? "进攻" : modules.A.structural.state === "defense" ? "防守" : "中性"}，T1/T3/T6 投票 ${Object.values(modules.A.structural.votes).map((vote) => (vote === "up" ? "上" : vote === "down" ? "下" : "中")).join("/")}`
      : "指数历史不足",
    B: modules.B
      ? `站上 EMA20 ${round(modules.B.subitems.B1.coverage * 100, 1)}%，强涨跌净广度 ${round(modules.B.subitems.B2.smooth_net * 100, 1)}%`
      : "全市场宽度数据未闭合",
    C: modules.C
      ? `成交容量比 ${round(modules.C.subitems.C1.smooth, 2)}，涨跌成交净额 ${round(modules.C.subitems.C4.smooth * 100, 1)}%`
      : "成交历史不足",
    D: modules.D
      ? modules.D.status === "complete"
        ? `三指数波动安全 ${round(modules.D.subitems.D1.score + modules.D.subitems.D2.score + modules.D.subitems.D3.score, 1)}/11，左尾风险分位 ${round(modules.D.subitems.D4.percentile * 100, 1)}%`
        : `五年横截面基线 ${modules.D.baseline.sessions}/${modules.D.baseline.required_sessions} 日`
      : "风险数据不可用",
    E: modules.E
      ? `行业 EMA20 覆盖 ${round(modules.E.subitems.E1.smooth * 100, 1)}%，龙头延续 ${round(modules.E.subitems.E3.persistence * 100, 1)}%`
      : "申万行业历史未闭合",
    F: modules.F
      ? `最高 ${modules.F.subitems.F3.board_height} 板，封板率 ${round(modules.F.subitems.F5.seal_rate * 100, 1)}%`
      : "涨跌停官方事件数据未闭合",
  };
}

function executionPermission(state, modules, riskOverlay) {
  if (riskOverlay.level === "R2" || state.market_state === "unavailable") {
    return { permission: "hold_or_reduce", position_action: "hold_or_reduce" };
  }
  if (state.market_state === "defense" || (modules.A?.t7_average ?? 1) <= 0.6) {
    return { permission: "hold_or_reduce", position_action: "hold_or_reduce" };
  }
  if (riskOverlay.level === "R1") {
    return { permission: "no_new_risk", position_action: "do_not_increase" };
  }
  return { permission: "normal", position_action: "move_toward_target" };
}

async function readJsonIfExists(file, fallback = null) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    return fallback;
  }
}

export async function loadBaseline(dataDir = config.dataDir) {
  return (
    (await readJsonIfExists(path.join(dataDir, "baseline.json"), null)) ||
    (await readJsonIfExists(path.join(config.defaultDataDir, "baseline.json"), null)) || {
      observations: [],
      generated_at: null,
    }
  );
}

export class MarketDataService {
  constructor({ client = new TushareClient(), dataDir = config.dataDir } = {}) {
    this.client = client;
    this.dataDir = dataDir;
  }

  async collect({ refresh = false, historyReports = [], asOf = "" } = {}) {
    const requestedDate = String(asOf || "").replaceAll("-", "");
    const today = /^\d{8}$/.test(requestedDate)
      ? `${requestedDate.slice(0, 4)}-${requestedDate.slice(4, 6)}-${requestedDate.slice(6, 8)}`
      : dateString(new Date());
    const historyStart = compactDate(addDays(today, -365 * 7));
    const end = compactDate(today);
    const sourceHealth = [];

    const indexSeries = {};
    for (const [code, name] of Object.entries(INDEX_DEFINITIONS)) {
      try {
        const rows = await this.client.request(
          "index_daily",
          { ts_code: code, start_date: historyStart, end_date: end },
          "ts_code,trade_date,open,high,low,close,vol,amount",
          { ttlSeconds: 900, refresh },
        );
        indexSeries[code] = normalizeIndexRows(rows);
      } catch (error) {
        sourceHealth.push({
          name: `指数日线 · ${name}`,
          api: "index_daily",
          status: "error",
          message: error.message,
        });
        throw error;
      }
    }
    sourceHealth.push({
      name: "三大指数日线",
      api: "index_daily",
      status: Object.values(indexSeries).every((rows) => rows.length >= 260) ? "ok" : "incomplete",
      records: Object.values(indexSeries).reduce((total, rows) => total + rows.length, 0),
    });

    const shRows = indexSeries["000001.SH"];
    if (!shRows?.length) throw new Error("上证指数日线为空");
    const marketDates = shRows.slice(-32).map((row) => row.trade_date);
    if (marketDates.length < 31) throw new Error("最近交易日不足 31 天");
    const currentDate = marketDates.at(-1);
    const previousReport =
      [...historyReports]
        .filter((report) => report?.trade_date < currentDate)
        .sort((left, right) => right.trade_date.localeCompare(left.trade_date))[0] || null;

    const stockRows = await this.client.request(
      "stock_basic",
      { exchange: "", list_status: "L" },
      "ts_code,symbol,name,area,industry,market,list_date,exchange",
      { ttlSeconds: 12 * 3600, refresh },
    );
    const stockMeta = new Map(
      stockRows
        .filter((row) => /(\.SH|\.SZ)$/.test(row.ts_code))
        .map((row) => [row.ts_code, row]),
    );
    sourceHealth.push({
      name: "沪深 A 股股票主表",
      api: "stock_basic",
      status: stockMeta.size > 3000 ? "ok" : "incomplete",
      records: stockMeta.size,
    });

    const stByDate = new Map();
    const stResults = await Promise.all(
      marketDates.map(async (tradeDate) => {
        try {
          const rows = await this.client.request(
            "stock_st",
            { trade_date: compactDate(tradeDate) },
            "ts_code,trade_date,type,type_name",
            { ttlSeconds: 3600, refresh },
          );
          return [tradeDate, { set: new Set(rows.map((row) => row.ts_code)), ok: true }];
        } catch {
          return [tradeDate, { set: new Set(), ok: false }];
        }
      }),
    );
    for (const [tradeDate, result] of stResults) stByDate.set(tradeDate, result);
    sourceHealth.push({
      name: "点时 ST 状态",
      api: "stock_st",
      status: stResults.every(([, result]) => result.ok) ? "ok" : "warning",
      records: stResults.reduce((total, [, result]) => total + result.set.size, 0),
    });

    const dailyByDate = new Map();
    const dailyResults = await Promise.all(
      marketDates.map(async (tradeDate) => {
        const rows = await this.client.request(
          "daily",
          { trade_date: compactDate(tradeDate) },
          "ts_code,trade_date,open,high,low,close,pre_close,pct_chg,vol,amount",
          { ttlSeconds: 3600, refresh },
        );
        return [tradeDate, normalizeDailyRows(rows)];
      }),
    );
    for (const [tradeDate, rows] of dailyResults) dailyByDate.set(tradeDate, rows);
    const adjustmentDates = marketDates.slice(-31);
    const adjustmentResults = await Promise.all(
      adjustmentDates.map(async (tradeDate) => {
        try {
          const rows = await this.client.request(
            "adj_factor",
            { trade_date: compactDate(tradeDate) },
            "trade_date,ts_code,adj_factor",
            { ttlSeconds: 3600, refresh },
          );
          return [tradeDate, new Map(rows.map((row) => [row.ts_code, numeric(row.adj_factor)]))];
        } catch {
          return [tradeDate, new Map()];
        }
      }),
    );
    const adjustmentByDate = new Map(adjustmentResults);
    let adjustedRows = 0;
    for (const [tradeDate, rows] of dailyByDate) {
      const factors = adjustmentByDate.get(tradeDate);
      for (const row of rows) {
        const factor = factors?.get(row.ts_code);
        row.adj_close = row.close !== null && factor ? row.close * factor : row.close;
        if (factor) adjustedRows += 1;
      }
    }
    const totalDailyRows = [...dailyByDate.values()].reduce((total, rows) => total + rows.length, 0);
    sourceHealth.push({
      name: "复权因子",
      api: "adj_factor",
      status: totalDailyRows && adjustedRows / totalDailyRows >= 0.8 ? "ok" : "warning",
      records: adjustedRows,
    });
    const dailyIndexByDate = new Map(
      [...dailyByDate.entries()].map(([tradeDate, rows]) => [
        tradeDate,
        new Map(rows.map((row) => [row.ts_code, row])),
      ]),
    );
    const latestDaily = dailyByDate.get(currentDate) || [];
    sourceHealth.push({
      name: "全市场日线",
      api: "daily",
      status: latestDaily.length > 3000 ? "ok" : "incomplete",
      records: latestDaily.length,
    });

    const limitDates = marketDates.slice(-12);
    const limitsByDate = new Map();
    const limitResults = await Promise.all(
      limitDates.map(async (tradeDate) => {
        try {
          const rows = await this.client.request(
            "stk_limit",
            { trade_date: compactDate(tradeDate) },
            "trade_date,ts_code,up_limit,down_limit",
            { ttlSeconds: 3600, refresh },
          );
          return [tradeDate, mapByCode(rows)];
        } catch (error) {
          sourceHealth.push({
            name: `官方涨跌停价 · ${tradeDate}`,
            api: "stk_limit",
            status: "error",
            message: error.message,
          });
          return [tradeDate, new Map()];
        }
      }),
    );
    for (const [tradeDate, rows] of limitResults) limitsByDate.set(tradeDate, rows);
    const limitCoverage = limitsByDate.get(currentDate)?.size / Math.max(1, latestDaily.length);
    sourceHealth.push({
      name: "官方涨跌停价",
      api: "stk_limit",
      status: limitCoverage >= 0.9 ? "ok" : "incomplete",
      records: limitsByDate.get(currentDate)?.size || 0,
    });

    const suspendedByDate = new Map();
    for (const tradeDate of marketDates.slice(-2)) {
      try {
        const rows = await this.client.request(
          "suspend_d",
          {
            trade_date: compactDate(tradeDate),
            suspend_type: "S",
          },
          "ts_code,trade_date,suspend_timing,suspend_type",
          { ttlSeconds: 3600, refresh },
        );
        suspendedByDate.set(tradeDate, new Set(rows.map((row) => row.ts_code)));
      } catch (error) {
        suspendedByDate.set(tradeDate, new Set());
        sourceHealth.push({
          name: `停牌状态 · ${tradeDate}`,
          api: "suspend_d",
          status: "warning",
          message: `接口不可用；缺失日线按停牌/不可交易处理。${error.message}`,
        });
      }
    }

    const marketData = {
      dates: marketDates,
      dailyByDate,
      dailyIndexByDate,
      limitsByDate,
      suspendedByDate,
      stByDate,
      stockMeta,
      currentDate,
    };

    const trend = calculateTrendModule(indexSeries, previousReport);
    const breadth = calculateBreadth(marketData);
    const liquidity = calculateLiquidity(marketData);
    const baseline = await loadBaseline(this.dataDir);
    const risk = calculateRisk(marketData, trend.index_d, baseline);

    let industries = [];
    try {
      const classifications = await this.client.request(
        "index_classify",
        { level: "L1", src: "SW2021" },
        "index_code,industry_name,level,industry_code,is_pub,parent_code",
        { ttlSeconds: 24 * 3600, refresh },
      );
      const industryResults = await Promise.all(
        classifications.map(async (industry) => {
          try {
            const rows = await this.client.request(
              "sw_daily",
              {
                ts_code: industry.index_code,
                start_date: compactDate(addDays(currentDate, -120)),
                end_date: compactDate(currentDate),
              },
              "ts_code,trade_date,close",
              { ttlSeconds: 3600, refresh },
            );
            return {
              code: industry.index_code,
              name: industry.industry_name,
              rows: rows
                .map((row) => ({
                  trade_date: normalizeDate(row.trade_date),
                  close: numeric(row.close),
                }))
                .filter((row) => row.close !== null)
                .sort((left, right) => left.trade_date.localeCompare(right.trade_date)),
            };
          } catch {
            return null;
          }
        }),
      );
      industries = industryResults.filter(Boolean);
      sourceHealth.push({
        name: "申万一级行业指数",
        api: "sw_daily",
        status: industries.length / Math.max(1, classifications.length) >= 0.9 ? "ok" : "incomplete",
        records: industries.length,
        expected: classifications.length,
      });
    } catch (error) {
      sourceHealth.push({
        name: "申万一级行业指数",
        api: "sw_daily",
        status: "error",
        message: error.message,
      });
    }

    const structure = calculateStructure(
      marketData,
      industries,
      trend.module.index_details,
    );
    const ecology = calculateEcology(marketData);
    const modules = { A: trend.module, B: breadth, C: liquidity, D: risk, E: structure, F: ecology };
    const complete = Object.values(modules).every((module) => module.status === "complete");
    const totalScore = complete
      ? Object.values(modules).reduce((total, module) => total + module.score, 0)
      : null;
    const state = updateStateMachine({
      complete,
      totalScore,
      trendModule: modules.A,
      breadthModule: modules.B,
      riskOverlay: trend.risk_overlay,
      previousReport,
    });
    const execution = executionPermission(state, modules, trend.risk_overlay);
    const copy = buildConfirmationsAndDivergences(modules);
    const drivers = moduleDrivers(modules);
    const dataStatus = complete
      ? "complete"
      : Object.values(modules).some((module) => module.status === "initializing")
        ? "initializing"
        : "incomplete";
    const warnings = [
      "A–F 为确定性规则输出，不是个性化投资建议。",
      "C–F 使用 V0.1 工程参数，尚未完成商业验证。",
      "收盘信号从下一交易日开始生效，不能假设按当日收盘成交。",
    ];
    if (risk.baseline.status !== "ready") {
      warnings.push(
        `D4–D5 五年风险基线正在建立（${risk.baseline.sessions}/${risk.baseline.required_sessions} 个交易日）。基线达到 250 日后才参与总分。`,
      );
    }
    if (!limitsByDate.get(currentDate)?.size) {
      warnings.push("Tushare stk_limit 未返回官方涨跌停价，B5 与 F 模块会保持未完成。");
    }
    if (!industries.length) {
      warnings.push("Tushare 申万一级行业指数不可用，E 模块保持未完成。");
    }

    const chartIndices = {};
    for (const [code, name] of Object.entries(INDEX_DEFINITIONS)) {
      const rows = indexSeries[code];
      const latest = rows.at(-1);
      chartIndices[code] = {
        code,
        name,
        close: latest.close,
        change_pct: latest.close / rows.at(-2).close - 1,
        atr20: trend.module.index_details[name].atr20,
        rows: lineChartRows(rows),
      };
    }

    const generatedAt = new Date().toISOString();
    return {
      trade_date: currentDate,
      generated_at: generatedAt,
      evaluation_timestamp: `${currentDate}T15:00:00+08:00`,
      framework_version: "market-state-a-f-100-state-machine-v0.2",
      data_status: dataStatus,
      source: "Tushare Pro",
      ...state,
      trend_structural_state: modules.A.structural.state,
      trend_structural_state_source: modules.A.version,
      modules,
      module_meta: Object.fromEntries(
        Object.entries(modules).map(([key, module]) => [
          key,
          {
            name: MODULE_NAMES[key],
            score: moduleRows(module),
            max: module.max,
            status: module.status,
            version: module.version,
            driver: drivers[key],
          },
        ]),
      ),
      total_score: totalScore,
      max_score: 100,
      guidance_position_pct: totalScore,
      risk_overlay: trend.risk_overlay,
      execution,
      confirmations: copy.confirmations,
      divergences: copy.divergences,
      indices: chartIndices,
      data_quality: {
        sources: sourceHealth,
        complete_modules: Object.values(modules).filter((module) => module.status === "complete").length,
        total_modules: 6,
        universe_size: breadth.universe.n_t,
        baseline_sessions: risk.baseline.sessions,
        baseline_required: risk.baseline.required_sessions,
      },
      warnings,
    };
  }
}

export function summarizeModules(report) {
  return Object.fromEntries(
    Object.entries(report.modules || {}).map(([key, module]) => [
      key,
      {
        score: moduleRows(module),
        max: module.max,
        status: module.status,
      },
    ]),
  );
}
