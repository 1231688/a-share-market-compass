import {
  clamp,
  ema,
  isFiniteNumber,
  linearAnchors,
  mean,
  quantile,
  sum,
  topShare,
} from "./math.js";

const EPSILON = 1e-12;
const LIMIT_TOLERANCE = 0.015;

function value(row, key) {
  const parsed = Number(row?.[key]);
  return Number.isFinite(parsed) ? parsed : null;
}

function dayRows(marketData, dayIndex) {
  return marketData.dailyByDate.get(marketData.dates[dayIndex]) || [];
}

function limitFor(marketData, dayIndex, code) {
  return marketData.limitsByDate.get(marketData.dates[dayIndex])?.get(code) || null;
}

function isSuspended(marketData, dayIndex, code) {
  return marketData.suspendedByDate.get(marketData.dates[dayIndex])?.has(code) || false;
}

function isRiskName(name = "") {
  return /ST|退/.test(String(name).toUpperCase());
}

function listingAgeDays(stock, tradeDate) {
  if (!stock?.list_date) return null;
  const listed = new Date(
    `${String(stock.list_date).slice(0, 4)}-${String(stock.list_date).slice(4, 6)}-${String(stock.list_date).slice(6, 8)}T00:00:00+08:00`,
  );
  const current = new Date(`${tradeDate}T00:00:00+08:00`);
  return Math.floor((current - listed) / 86_400_000);
}

function baseEligibleCodes(marketData, dayIndex) {
  const tradeDate = marketData.dates[dayIndex];
  const rowsByCode =
    marketData.dailyIndexByDate?.get(tradeDate) ||
    new Map(dayRows(marketData, dayIndex).map((row) => [row.ts_code, row]));
  const stStatus = marketData.stByDate?.get(tradeDate);
  const codes = [];
  for (const [code, stock] of marketData.stockMeta) {
    if (!/(\.SH|\.SZ)$/.test(code)) continue;
    if (stStatus?.ok ? stStatus.set.has(code) : isRiskName(stock.name)) continue;
    const age = listingAgeDays(stock, tradeDate);
    if (age === null || age < 90) continue;
    if (!rowsByCode.has(code)) continue;
    if (isSuspended(marketData, dayIndex, code)) continue;
    codes.push(code);
  }
  return codes;
}

function seriesWindow(marketData, code, dayIndex, field, count) {
  const output = [];
  for (let cursor = dayIndex - count + 1; cursor <= dayIndex; cursor += 1) {
    if (cursor < 0) return null;
    const tradeDate = marketData.dates[cursor];
    const row =
      marketData.dailyIndexByDate?.get(tradeDate)?.get(code) ||
      dayRows(marketData, cursor).find((item) => item.ts_code === code);
    const numeric = value(row, field);
    if (numeric === null) return null;
    output.push(numeric);
  }
  return output;
}

function rowFor(marketData, dayIndex, code) {
  const tradeDate = marketData.dates[dayIndex];
  return (
    marketData.dailyIndexByDate?.get(tradeDate)?.get(code) ||
    dayRows(marketData, dayIndex).find((item) => item.ts_code === code) ||
    null
  );
}

function piecewiseCoverage(value, low, middle, high, maximum) {
  if (!isFiniteNumber(value)) return null;
  if (value <= low) return 0;
  if (value <= middle) return (maximum / 2) * ((value - low) / (middle - low));
  if (value < high) return maximum / 2 + (maximum / 2) * ((value - middle) / (high - middle));
  return maximum;
}

function strongScore(netExtreme) {
  return clamp(1.5 + 15 * netExtreme, 0, 3);
}

function scoreLimitStructure(direction, participation, previousDirection, previousParticipation) {
  const intensity = clamp(participation / 0.02, 0, 1);
  const raw = direction * intensity;
  const previousRaw = previousDirection * clamp(previousParticipation / 0.02, 0, 1);
  const smooth = (2 * raw + previousRaw) / 3;
  return { raw, previous_raw: previousRaw, smooth, score: clamp(1.5 + 1.5 * smooth, 0, 3) };
}

function closedAtUpLimit(row, limit) {
  return Boolean(
    row &&
      limit &&
      Math.abs(value(row, "close") - value(limit, "up_limit")) <= LIMIT_TOLERANCE,
  );
}

function closedAtDownLimit(row, limit) {
  return Boolean(
    row &&
      limit &&
      Math.abs(value(row, "close") - value(limit, "down_limit")) <= LIMIT_TOLERANCE,
  );
}

function touchedUpLimit(row, limit) {
  return Boolean(
    row &&
      limit &&
      value(row, "high") >= value(limit, "up_limit") - LIMIT_TOLERANCE,
  );
}

function boardStreak(marketData, code, dayIndex) {
  let streak = 0;
  for (let cursor = dayIndex; cursor >= 0 && cursor >= dayIndex - 20; cursor -= 1) {
    const row = rowFor(marketData, cursor, code);
    const limit = limitFor(marketData, cursor, code);
    if (!closedAtUpLimit(row, limit)) break;
    streak += 1;
  }
  return streak;
}

function amountTotal(marketData, dayIndex) {
  const codes = baseEligibleCodes(marketData, dayIndex);
  const codeSet = new Set(codes);
  const rows = dayRows(marketData, dayIndex).filter(
    (row) => codeSet.has(row.ts_code) && value(row, "amount_cny") !== null,
  );
  return {
    codes,
    rows,
    total: sum(rows.map((row) => row.amount_cny)),
  };
}

export function calculateBreadth(marketData) {
  const currentIndex = marketData.dates.length - 1;
  const previousIndex = currentIndex - 1;
  const currentCodes = baseEligibleCodes(marketData, currentIndex);
  const previousCodes = baseEligibleCodes(marketData, previousIndex);
  const twoDaysBackCodes = baseEligibleCodes(marketData, currentIndex - 2);
  const emaChecks = [];

  for (const code of currentCodes) {
    const closes = seriesWindow(marketData, code, currentIndex, "adj_close", 20);
    if (!closes) continue;
    const ema20 = ema(closes, 20).at(-1);
    emaChecks.push({ code, above: closes.at(-1) > ema20 });
  }
  const aboveEma20 = emaChecks.filter((item) => item.above).length;
  const b1Coverage = currentCodes.length ? aboveEma20 / currentCodes.length : null;
  const b1DataCoverage = currentCodes.length ? emaChecks.length / currentCodes.length : null;
  const b1 = piecewiseCoverage(b1Coverage, 0.2, 0.5, 0.9, 5);

  function strongMetric(dayIndex, codes) {
    const codeSet = new Set(codes);
    const rows = dayRows(marketData, dayIndex).filter((row) => codeSet.has(row.ts_code));
    const changes = rows
      .map((row) => value(row, "pct_chg_ratio"))
      .filter((item) => item !== null);
    const strongUp = changes.filter((item) => item >= 0.035).length;
    const strongDown = changes.filter((item) => item <= -0.035).length;
    return {
      n: codes.length,
      strong_up: strongUp,
      strong_down: strongDown,
      net: codes.length ? (strongUp - strongDown) / codes.length : null,
      participation: codes.length ? (strongUp + strongDown) / codes.length : null,
    };
  }
  const strongCurrent = strongMetric(currentIndex, currentCodes);
  const strongPrevious = strongMetric(previousIndex, previousCodes);
  const smoothStrong = (2 * strongCurrent.net + strongPrevious.net) / 3;
  const b2 = clamp(2.5 + 12.5 * smoothStrong, 0, 5);

  function advanceMetric(dayIndex, codes) {
    const codeSet = new Set(codes);
    const changes = dayRows(marketData, dayIndex)
      .filter((row) => codeSet.has(row.ts_code))
      .map((row) => value(row, "pct_chg_ratio"))
      .filter((item) => item !== null);
    const advancing = changes.filter((item) => item > 0).length;
    const declining = changes.filter((item) => item < 0).length;
    return {
      advancing,
      declining,
      raw: advancing + declining ? advancing / (advancing + declining) : null,
    };
  }
  const advanceCurrent = advanceMetric(currentIndex, currentCodes);
  const advancePrevious = advanceMetric(previousIndex, previousCodes);
  const advanceTwo = advanceMetric(currentIndex - 2, twoDaysBackCodes);
  const p3 = mean([advanceCurrent.raw, advancePrevious.raw, advanceTwo.raw]);
  const b3 = piecewiseCoverage(p3, 0.2, 0.5, 0.9, 4);

  function highLowMetric(dayIndex, codes) {
    let newHighs = 0;
    let newLows = 0;
    let evaluated = 0;
    for (const code of codes) {
      const closes = seriesWindow(marketData, code, dayIndex, "adj_close", 31);
      if (!closes) continue;
      evaluated += 1;
      const historicHigh = Math.max(...closes.slice(0, -1));
      const historicLow = Math.min(...closes.slice(0, -1));
      if (closes.at(-1) > historicHigh) newHighs += 1;
      if (closes.at(-1) < historicLow) newLows += 1;
    }
    return {
      new_highs: newHighs,
      new_lows: newLows,
      evaluated,
      net: evaluated ? (newHighs - newLows) / evaluated : null,
      participation: evaluated ? (newHighs + newLows) / evaluated : null,
    };
  }
  const highLowCurrent = highLowMetric(currentIndex, currentCodes);
  const highLowPrevious = highLowMetric(previousIndex, previousCodes);
  const smoothExtreme = (2 * highLowCurrent.net + highLowPrevious.net) / 3;
  const b4 = strongScore(smoothExtreme);

  function limitMetric(dayIndex, codes) {
    let limitUp = 0;
    let limitDown = 0;
    let touched = 0;
    let covered = 0;
    for (const code of codes) {
      const row = rowFor(marketData, dayIndex, code);
      const limit = limitFor(marketData, dayIndex, code);
      if (!row || !limit) continue;
      covered += 1;
      if (closedAtUpLimit(row, limit)) limitUp += 1;
      if (closedAtDownLimit(row, limit)) limitDown += 1;
      if (touchedUpLimit(row, limit)) touched += 1;
    }
    const denominator = limitUp + limitDown;
    return {
      limit_up: limitUp,
      limit_down: limitDown,
      touched_up: touched,
      covered,
      coverage: codes.length ? covered / codes.length : 0,
      direction: denominator ? (limitUp - limitDown) / (denominator + EPSILON) : 0,
      participation: codes.length ? denominator / codes.length : null,
      seal_rate: touched ? limitUp / touched : null,
      blow_rate: touched ? (touched - limitUp) / touched : null,
    };
  }
  const limitsCurrent = limitMetric(currentIndex, currentCodes);
  const limitsPrevious = limitMetric(previousIndex, previousCodes);
  const limitStructure = scoreLimitStructure(
    limitsCurrent.direction,
    limitsCurrent.participation,
    limitsPrevious.direction,
    limitsPrevious.participation,
  );
  const limitCoverageOk = limitsCurrent.coverage >= 0.9 && limitsPrevious.coverage >= 0.9;
  const b5 = limitCoverageOk
    ? scoreLimitStructure(
        limitsCurrent.direction,
        limitsCurrent.participation,
        limitsPrevious.direction,
        limitsPrevious.participation,
      ).score
    : null;
  const complete =
    [b1, b2, b3, b4, b5].every(isFiniteNumber) &&
    b1DataCoverage >= 0.8 &&
    highLowCurrent.evaluated / currentCodes.length >= 0.8;
  const score = complete ? b1 + b2 + b3 + b4 + b5 : null;

  return {
    score,
    max: 20,
    status: complete ? "complete" : "incomplete",
    version: "B-market-breadth-v1.0",
    universe: {
      n_t: currentCodes.length,
      n_t_minus_1: previousCodes.length,
      n_t_minus_2: twoDaysBackCodes.length,
      ema20_coverage: b1Coverage,
      ema20_data_coverage: b1DataCoverage,
    },
    subitems: {
      B1: {
        score: b1,
        max: 5,
        above_ema20: aboveEma20,
        valid_ema20: emaChecks.length,
        coverage: b1Coverage,
      },
      B2: {
        score: b2,
        max: 5,
        today: strongCurrent,
        previous: strongPrevious,
        smooth_net: smoothStrong,
        extreme_warning: Math.abs(strongCurrent.net) >= 0.2,
      },
      B3: {
        score: b3,
        max: 4,
        today: advanceCurrent,
        previous: advancePrevious,
        two_days_back: advanceTwo,
        p3,
      },
      B4: {
        score: b4,
        max: 3,
        today: highLowCurrent,
        previous: highLowPrevious,
        smooth_extreme: smoothExtreme,
      },
      B5: {
        score: b5,
        max: 3,
        today: limitsCurrent,
        previous: limitsPrevious,
        smooth: limitStructure.smooth,
        official_limit_coverage_ok: limitCoverageOk,
      },
    },
  };
}

export function calculateLiquidity(marketData) {
  const currentIndex = marketData.dates.length - 1;
  const currentCodes = baseEligibleCodes(marketData, currentIndex);
  const previousCodes = baseEligibleCodes(marketData, currentIndex - 1);
  const currentCodeSet = new Set(currentCodes);
  const previousCodeSet = new Set(previousCodes);
  const totalByDay = [];
  for (let cursor = currentIndex - 20; cursor <= currentIndex; cursor += 1) {
    totalByDay.push(amountTotal(marketData, cursor).total);
  }
  const amountTotalCurrent = totalByDay.at(-1);
  const amountBase20 = quantile(totalByDay.slice(0, -1), 0.5);
  const ratioCurrent = amountBase20 ? amountTotalCurrent / amountBase20 : null;
  const ratioPreviousDay = amountTotal(marketData, currentIndex - 1).total;
  const basePrevious = quantile(totalByDay.slice(0, -2), 0.5);
  const ratioPrevious = basePrevious ? ratioPreviousDay / basePrevious : null;
  const smoothRatio = (2 * ratioCurrent + ratioPrevious) / 3;
  const c1 = linearAnchors(smoothRatio, [
    [0.7, 0],
    [0.85, 1],
    [1, 2],
    [1.2, 3],
    [1.5, 4],
  ]);

  function activeMetric(dayIndex, codes) {
    let active = 0;
    let valid = 0;
    for (const code of codes) {
      const amounts = seriesWindow(marketData, code, dayIndex, "amount_cny", 20);
      if (!amounts) continue;
      valid += 1;
      if (amounts.at(-1) > ema(amounts, 20).at(-1)) active += 1;
    }
    return { active, valid, raw: valid ? active / valid : null };
  }
  const activeCurrent = activeMetric(currentIndex, currentCodes);
  const activePrevious = activeMetric(currentIndex - 1, previousCodes);
  const smoothActive = (2 * activeCurrent.raw + activePrevious.raw) / 3;
  const c2 = linearAnchors(smoothActive, [
    [0.2, 0],
    [0.5, 2],
    [0.8, 4],
  ]);

  const rowsCurrent = dayRows(marketData, currentIndex).filter(
    (row) => currentCodeSet.has(row.ts_code) && value(row, "amount_cny") !== null,
  );
  const rowsPrevious = dayRows(marketData, currentIndex - 1).filter(
    (row) => previousCodeSet.has(row.ts_code) && value(row, "amount_cny") !== null,
  );
  const concentrationCurrent = topShare(rowsCurrent, "amount_cny", 0.1);
  const concentrationPrevious = topShare(rowsPrevious, "amount_cny", 0.1);
  const smoothConcentration = (2 * concentrationCurrent + concentrationPrevious) / 3;
  const c3 = linearAnchors(smoothConcentration, [
    [0.25, 3],
    [0.35, 1.5],
    [0.5, 0],
  ]);

  function turnoverDirection(rows, total) {
    const amountUp = sum(
      rows
        .filter((row) => value(row, "pct_chg_ratio") > 0)
        .map((row) => row.amount_cny),
    );
    const amountDown = sum(
      rows
        .filter((row) => value(row, "pct_chg_ratio") < 0)
        .map((row) => row.amount_cny),
    );
    return total ? (amountUp - amountDown) / total : null;
  }
  const totalCurrentRows = sum(rowsCurrent.map((row) => row.amount_cny));
  const totalPreviousRows = sum(rowsPrevious.map((row) => row.amount_cny));
  const directionCurrent = turnoverDirection(rowsCurrent, totalCurrentRows);
  const directionPrevious = turnoverDirection(rowsPrevious, totalPreviousRows);
  const smoothDirection = (2 * directionCurrent + directionPrevious) / 3;
  const c4 = clamp(2 + (2 * smoothDirection) / 0.3, 0, 4);
  const subitems = { C1: c1, C2: c2, C3: c3, C4: c4 };
  const complete =
    Object.values(subitems).every(isFiniteNumber) &&
    activeCurrent.valid / currentCodes.length >= 0.8;
  const score = complete ? c1 + c2 + c3 + c4 : null;

  return {
    score,
    max: 15,
    status: complete ? "complete" : "incomplete",
    version: "C-turnover-liquidity-v0.1",
    unit: "CNY",
    subitems: {
      C1: {
        score: c1,
        max: 4,
        amount_total_cny: amountTotalCurrent,
        base20_cny: amountBase20,
        ratio_t: ratioCurrent,
        smooth: smoothRatio,
      },
      C2: {
        score: c2,
        max: 4,
        today: activeCurrent,
        previous: activePrevious,
        smooth: smoothActive,
      },
      C3: {
        score: c3,
        max: 3,
        today_concentration10: concentrationCurrent,
        previous_concentration10: concentrationPrevious,
        smooth: smoothConcentration,
      },
      C4: {
        score: c4,
        max: 4,
        today_net: directionCurrent,
        previous_net: directionPrevious,
        smooth: smoothDirection,
      },
    },
  };
}

export function calculateCrossSectionStats(marketData, dayIndex) {
  const changes = dayRows(marketData, dayIndex)
    .filter((row) => /(\.SH|\.SZ)$/.test(row.ts_code))
    .map((row) => value(row, "pct_chg_ratio"))
    .filter((item) => item !== null);
  if (changes.length < 100) return null;
  return {
    trade_date: marketData.dates[dayIndex],
    sample_size: changes.length,
    left_tail_raw: -(quantile(changes, 0.05) ?? 0),
    dispersion_raw: (quantile(changes, 0.75) ?? 0) - (quantile(changes, 0.25) ?? 0),
  };
}

function baselinePercentile(observations, key, current, beforeDate) {
  const values = observations
    .filter((item) => item.trade_date < beforeDate)
    .map((item) => Number(item[key]))
    .filter(Number.isFinite);
  if (values.length < 250 || !isFiniteNumber(current)) return null;
  return values.filter((item) => item <= current).length / values.length;
}

export function calculateRisk(marketData, indexD, baseline = null) {
  const currentIndex = marketData.dates.length - 1;
  const currentDate = marketData.dates[currentIndex];
  const indexCurrent = {
    D1: mean(Object.values(indexD).map((item) => item.d1)),
    D2: mean(Object.values(indexD).map((item) => item.d2)),
    D3: mean(Object.values(indexD).map((item) => item.d3)),
  };
  const statsCurrent = calculateCrossSectionStats(marketData, currentIndex);
  const statsPrevious = calculateCrossSectionStats(marketData, currentIndex - 1);
  const statsTwo = calculateCrossSectionStats(marketData, currentIndex - 2);
  const observations = baseline?.observations || [];
  const leftTailSmooth =
    statsCurrent && statsPrevious
      ? (2 * statsCurrent.left_tail_raw + statsPrevious.left_tail_raw) / 3
      : null;
  const dispersionSmooth =
    statsCurrent && statsPrevious && statsTwo
      ? (statsCurrent.dispersion_raw +
          statsPrevious.dispersion_raw +
          statsTwo.dispersion_raw) /
        3
      : null;
  const pctTail = baselinePercentile(observations, "left_tail_raw", leftTailSmooth, currentDate);
  const pctDispersion = baselinePercentile(
    observations,
    "dispersion_raw",
    dispersionSmooth,
    currentDate,
  );
  const d4 = pctTail === null ? null : 2 * (1 - pctTail);
  const d5 = pctDispersion === null ? null : 2 * (1 - pctDispersion);
  const complete =
    [indexCurrent.D1, indexCurrent.D2, indexCurrent.D3, d4, d5].every(isFiniteNumber) &&
    observations.length >= 250;
  const score = complete
    ? indexCurrent.D1 + indexCurrent.D2 + indexCurrent.D3 + d4 + d5
    : null;

  return {
    score,
    max: 15,
    status: complete ? "complete" : "initializing",
    version: "D-volatility-downside-risk-v0.1",
    subitems: {
      D1: { score: indexCurrent.D1, max: 4 },
      D2: { score: indexCurrent.D2, max: 4 },
      D3: { score: indexCurrent.D3, max: 3 },
      D4: {
        score: d4,
        max: 2,
        left_tail_raw: statsCurrent?.left_tail_raw ?? null,
        smooth: leftTailSmooth,
        percentile: pctTail,
      },
      D5: {
        score: d5,
        max: 2,
        dispersion_raw: statsCurrent?.dispersion_raw ?? null,
        smooth: dispersionSmooth,
        percentile: pctDispersion,
      },
    },
    baseline: {
      sessions: observations.length,
      required_sessions: 250,
      status: observations.length >= 250 ? "ready" : "initializing",
    },
    cross_section_quality: {
      universe_count: statsCurrent?.sample_size ?? null,
      coverage: statsCurrent?.sample_size ? statsCurrent.sample_size / marketData.stockMeta.size : null,
    },
  };
}

function findRowByDate(rows, tradeDate) {
  return rows.find((row) => row.trade_date === tradeDate) || null;
}

function industryReturn(industry, tradeDate, window = 20) {
  const end = industry.rows.findIndex((row) => row.trade_date === tradeDate);
  if (end < window) return null;
  const start = industry.rows[end - window];
  const finish = industry.rows[end];
  if (!start?.close || !finish?.close) return null;
  return finish.close / start.close - 1;
}

function industryWindow(industry, tradeDate, count) {
  const end = industry.rows.findIndex((row) => row.trade_date === tradeDate);
  if (end < count - 1) return null;
  return industry.rows.slice(end - count + 1, end + 1).map((row) => row.close);
}

function leaderSet(industries, tradeDate) {
  const ranked = industries
    .map((industry) => ({ code: industry.code, value: industryReturn(industry, tradeDate) }))
    .filter((item) => isFiniteNumber(item.value))
    .sort((left, right) => right.value - left.value);
  const count = Math.max(1, Math.ceil(ranked.length * 0.2));
  return ranked.slice(0, count).map((item) => item.code);
}

export function calculateStructure(marketData, industries, indexDetails) {
  const currentIndex = marketData.dates.length - 1;
  const currentDate = marketData.dates[currentIndex];
  const previousDate = marketData.dates[currentIndex - 1];
  const validIndustries = [];
  let aboveCurrent = 0;
  let abovePrevious = 0;
  let newHighs = 0;
  let newLows = 0;
  let previousHighs = 0;
  let previousLows = 0;

  for (const industry of industries) {
    const currentWindow = industryWindow(industry, currentDate, 20);
    const previousWindow = industryWindow(industry, previousDate, 20);
    if (!currentWindow || !previousWindow) continue;
    validIndustries.push(industry);
    if (currentWindow.at(-1) > ema(currentWindow, 20).at(-1)) aboveCurrent += 1;
    if (previousWindow.at(-1) > ema(previousWindow, 20).at(-1)) abovePrevious += 1;
    const highCurrent = Math.max(...currentWindow.slice(0, -1));
    const lowCurrent = Math.min(...currentWindow.slice(0, -1));
    const highPrevious = Math.max(...previousWindow.slice(0, -1));
    const lowPrevious = Math.min(...previousWindow.slice(0, -1));
    if (currentWindow.at(-1) > highCurrent) newHighs += 1;
    if (currentWindow.at(-1) < lowCurrent) newLows += 1;
    if (previousWindow.at(-1) > highPrevious) previousHighs += 1;
    if (previousWindow.at(-1) < lowPrevious) previousLows += 1;
  }

  const coverage = industries.length ? validIndustries.length / industries.length : 0;
  const aboveCurrentRatio = validIndustries.length ? aboveCurrent / validIndustries.length : null;
  const abovePreviousRatio = validIndustries.length ? abovePrevious / validIndustries.length : null;
  const smoothAbove = (2 * aboveCurrentRatio + abovePreviousRatio) / 3;
  const e1 = linearAnchors(smoothAbove, [
    [0.2, 0],
    [0.5, 1.5],
    [0.8, 3],
  ]);
  const netCurrent =
    validIndustries.length ? (newHighs - newLows) / validIndustries.length : null;
  const netPrevious =
    validIndustries.length ? (previousHighs - previousLows) / validIndustries.length : null;
  const smoothNet = (2 * netCurrent + netPrevious) / 3;
  const e2 = clamp(1 + smoothNet / 0.3, 0, 2);

  const dates = Array.from({ length: 5 }, (_, offset) => marketData.dates[currentIndex - offset]);
  const leaderSets = Object.fromEntries(dates.map((date) => [date, leaderSet(validIndustries, date)]));
  const currentLeaders = leaderSets[currentDate] || [];
  let overlap = 0;
  for (const code of currentLeaders) {
    for (let offset = 1; offset <= 4; offset += 1) {
      if ((leaderSets[dates[offset]] || []).includes(code)) overlap += 1;
    }
  }
  const persistence = currentLeaders.length ? overlap / (4 * currentLeaders.length) : null;
  const e3 = persistence === null ? null : 3 * persistence;
  const indexStates = Object.fromEntries(
    Object.entries(indexDetails).map(([name, item]) => [name, item.E4_state]),
  );
  const stateSum = mean(Object.values(indexStates));
  const e4 = 2 * ((stateSum + 1) / 2);
  const subitems = { E1: e1, E2: e2, E3: e3, E4: e4 };
  const complete = Object.values(subitems).every(isFiniteNumber) && coverage >= 0.9;
  const score = complete ? e1 + e2 + e3 + e4 : null;

  return {
    score,
    max: 10,
    status: complete ? "complete" : "incomplete",
    version: "E-market-structure-v0.1",
    classification: "申万一级行业",
    construction_method: "Tushare sw_daily industry indices",
    k: validIndustries.length,
    coverage,
    subitems: {
      E1: {
        score: e1,
        max: 3,
        above_t: aboveCurrentRatio,
        above_previous: abovePreviousRatio,
        smooth: smoothAbove,
      },
      E2: {
        score: e2,
        max: 2,
        today: { new_highs: newHighs, new_lows: newLows, net: netCurrent },
        previous: { new_highs: previousHighs, new_lows: previousLows, net: netPrevious },
        smooth: smoothNet,
      },
      E3: { score: e3, max: 3, persistence, leader_sets: leaderSets },
      E4: { score: e4, max: 2, index_states: indexStates },
    },
  };
}

function ecologyForDay(marketData, dayIndex) {
  const codes = baseEligibleCodes(marketData, dayIndex);
  const previousCodes = baseEligibleCodes(marketData, dayIndex - 1);
  const limitCoverageCodes = codes.filter(
    (code) => rowFor(marketData, dayIndex, code) && limitFor(marketData, dayIndex, code),
  );
  const coverage = codes.length ? limitCoverageCodes.length / codes.length : 0;
  let firstLimitUp = 0;
  let limitDown = 0;
  let touched = 0;
  let closedLimitUp = 0;
  let boardHeight = 0;
  for (const code of codes) {
    const row = rowFor(marketData, dayIndex, code);
    const limit = limitFor(marketData, dayIndex, code);
    if (!row || !limit) continue;
    const streak = boardStreak(marketData, code, dayIndex);
    boardHeight = Math.max(boardHeight, streak);
    if (streak === 1) firstLimitUp += 1;
    if (closedAtDownLimit(row, limit)) limitDown += 1;
    if (touchedUpLimit(row, limit)) touched += 1;
    if (closedAtUpLimit(row, limit)) closedLimitUp += 1;
  }

  const candidates = codes.filter(
    (code) =>
      previousCodes.includes(code) &&
      boardStreak(marketData, code, dayIndex - 1) === 1,
  );
  const promoted = candidates.filter(
    (code) => boardStreak(marketData, code, dayIndex) === 2,
  ).length;
  const priorLimitUps = previousCodes.filter((code) =>
    closedAtUpLimit(rowFor(marketData, dayIndex - 1, code), limitFor(marketData, dayIndex - 1, code)),
  );
  const premiums = [];
  for (const code of priorLimitUps) {
    const currentRow = rowFor(marketData, dayIndex, code);
    const previousRow = rowFor(marketData, dayIndex - 1, code);
    if (!currentRow || !previousRow || !previousRow.close) continue;
    premiums.push(clamp(currentRow.close / previousRow.close - 1, -0.1, 0.1));
  }
  const denominator = firstLimitUp + limitDown;
  const direction = denominator ? (firstLimitUp - limitDown) / (denominator + EPSILON) : 0;
  const participation = codes.length ? denominator / codes.length : null;

  return {
    first_limit_up: firstLimitUp,
    limit_down: limitDown,
    direction,
    participation,
    f1_raw: direction * clamp(participation / 0.01, 0, 1),
    promotion_rate: candidates.length ? promoted / candidates.length : null,
    eligible_first_previous: candidates.length,
    promoted,
    board_height: boardHeight,
    premium: premiums.length ? mean(premiums) : null,
    premium_sample: premiums.length,
    seal_rate: touched ? closedLimitUp / touched : null,
    touch_limit_up: touched,
    close_limit_up: closedLimitUp,
    failed_limit_up: touched - closedLimitUp,
    coverage,
  };
}

export function calculateEcology(marketData) {
  const currentIndex = marketData.dates.length - 1;
  const current = ecologyForDay(marketData, currentIndex);
  const previous = ecologyForDay(marketData, currentIndex - 1);
  const smoothF1 = (2 * current.f1_raw + previous.f1_raw) / 3;
  const f1 = clamp(1 + smoothF1, 0, 2);
  const f2Empty = current.eligible_first_previous === 0;
  const previousPromotion = previous.promotion_rate ?? current.promotion_rate;
  const smoothPromotion = f2Empty
    ? null
    : previousPromotion === null
      ? current.promotion_rate
      : (2 * current.promotion_rate + previousPromotion) / 3;
  const f2 = f2Empty
    ? 1
    : linearAnchors(smoothPromotion, [
        [0.1, 0],
        [0.3, 1],
        [0.5, 2],
      ]);
  const heightScore = (height) =>
    linearAnchors(height, [
      [0, 0.5],
      [1, 0.75],
      [2, 1],
      [4, 1.5],
      [6, 2],
    ]);
  const f3 = (2 * heightScore(current.board_height) + heightScore(previous.board_height)) / 3;
  const premiumEventEmpty = current.premium_sample === 0;
  const previousPremium = previous.premium ?? current.premium;
  const smoothPremium = premiumEventEmpty
    ? null
    : previousPremium === null
      ? current.premium
      : (2 * current.premium + previousPremium) / 3;
  const f4 = premiumEventEmpty
    ? 1
    : linearAnchors(smoothPremium, [
        [-0.03, 0],
        [0, 1],
        [0.03, 2],
      ]);
  const sealEventEmpty = current.touch_limit_up === 0;
  const previousSeal = previous.seal_rate ?? current.seal_rate;
  const smoothSeal = sealEventEmpty
    ? null
    : previousSeal === null
      ? current.seal_rate
      : (2 * current.seal_rate + previousSeal) / 3;
  const f5 = sealEventEmpty ? 1 : 2 * smoothSeal;
  const complete =
    [f1, f2, f3, f4, f5].every(isFiniteNumber) &&
    current.coverage >= 0.9 &&
    previous.coverage >= 0.9;
  const score = complete ? f1 + f2 + f3 + f4 + f5 : null;

  return {
    score,
    max: 10,
    status: complete ? "complete" : "incomplete",
    version: "F-sentiment-trading-ecology-v0.1",
    event_set_reconciliation: {
      today: current,
      previous,
    },
    subitems: {
      F1: {
        score: f1,
        max: 2,
        today: current,
        previous_f1_raw: previous.f1_raw,
        smooth: smoothF1,
      },
      F2: {
        score: f2,
        max: 2,
        smooth_promotion: smoothPromotion,
        event_empty: f2Empty,
      },
      F3: {
        score: f3,
        max: 2,
        raw_today: heightScore(current.board_height),
        raw_previous: heightScore(previous.board_height),
        board_height: current.board_height,
      },
      F4: {
        score: f4,
        max: 2,
        smooth_premium: smoothPremium,
        premium: current.premium,
        event_empty: premiumEventEmpty,
      },
      F5: {
        score: f5,
        max: 2,
        smooth_seal_rate: smoothSeal,
        seal_rate: current.seal_rate,
        event_empty: sealEventEmpty,
      },
    },
  };
}

export function updateStateMachine({
  complete,
  totalScore,
  trendModule,
  breadthModule,
  riskOverlay,
  previousReport,
}) {
  const previousState = previousReport?.market_state || "unavailable";
  if (!complete || !isFiniteNumber(totalScore)) {
    return {
      market_state: "unavailable",
      previous_market_state: previousState,
      state_reason: "A-F 模块存在未完成项，按规则不发布总分和指导仓位",
      attack_gate: false,
      defense_gate: false,
      attack_entry_counter: 0,
      hysteresis_active: false,
    };
  }
  const attackGate =
    totalScore >= 65 && trendModule.score >= 15 && breadthModule.score >= 11;
  const defenseGate = totalScore <= 35 || riskOverlay.extreme_risk_overlay;
  if (defenseGate) {
    return {
      market_state: "defense",
      previous_market_state: previousState,
      state_reason:
        totalScore <= 35
          ? "综合分不高于 35，触发立即防守"
          : "R2 极端风险覆盖触发立即防守",
      attack_gate: attackGate,
      defense_gate: true,
      attack_entry_counter: 0,
      hysteresis_active: false,
    };
  }
  const previousCounter = Number(previousReport?.attack_entry_counter) || 0;
  const attackCounter = attackGate ? previousCounter + 1 : 0;
  if (previousState === "attack" && totalScore >= 58) {
    return {
      market_state: "attack",
      previous_market_state: previousState,
      state_reason: "前一状态为进攻，且综合分保持在 58 以上，滞后缓冲继续保留",
      attack_gate: attackGate,
      defense_gate: false,
      attack_entry_counter: attackCounter,
      hysteresis_active: true,
    };
  }
  if (previousState === "defense" && totalScore <= 42) {
    return {
      market_state: "defense",
      previous_market_state: previousState,
      state_reason: "前一状态为防守，且综合分仍不高于 42，滞后缓冲继续保留",
      attack_gate: attackGate,
      defense_gate: false,
      attack_entry_counter: attackCounter,
      hysteresis_active: true,
    };
  }
  if (attackCounter >= 2) {
    return {
      market_state: "attack",
      previous_market_state: previousState,
      state_reason: "进攻门连续两个完整交易日满足",
      attack_gate: attackGate,
      defense_gate: false,
      attack_entry_counter: attackCounter,
      hysteresis_active: false,
    };
  }
  return {
    market_state: "neutral",
    previous_market_state: previousState,
    state_reason: attackGate
      ? "进攻门今日满足，但尚需连续第二个交易日确认"
      : "未满足进攻确认条件，也未触发防守门",
    attack_gate: attackGate,
    defense_gate: false,
    attack_entry_counter: attackCounter,
    hysteresis_active: false,
  };
}
