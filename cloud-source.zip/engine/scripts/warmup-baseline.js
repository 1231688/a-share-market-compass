import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { pathToFileURL } from "node:url";
import { config, assertLiveConfig } from "../src/config.js";
import { addDays, compactDate, dateString, quantile } from "../src/math.js";
import { TushareClient } from "../src/tushare.js";

function argument(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

async function readJson(file, fallback = null) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    return fallback;
  }
}

async function writeJson(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify(value), "utf8");
}

async function runPool(items, concurrency, worker) {
  const results = new Array(items.length);
  let cursor = 0;
  async function next() {
    while (cursor < items.length) {
      const current = cursor;
      cursor += 1;
      results[current] = await worker(items[current], current);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, next));
  return results;
}

export async function warmupBaseline(options = {}) {
  assertLiveConfig();
  const years = Number(options.years || config.warmupYears);
  const force = Boolean(options.force);
  const concurrency = Number(options.concurrency || 3);
  const dataDir = options.dataDir || config.dataDir;
  const baselinePath = path.join(dataDir, "baseline.json");
  const progressPath = path.join(dataDir, "baseline-progress.json");
  const endDate = options.endDate || dateString(new Date());
  const startDate = options.startDate || dateString(addDays(endDate, -Math.ceil(365.25 * years)));
  const client =
    options.client ||
    new TushareClient({
      requestsPerMinute: options.requestsPerMinute,
    });

  const stockStatuses = await Promise.all(
    ["L", "D", "P"].map((listStatus) =>
      client.request(
        "stock_basic",
        { exchange: "", list_status: listStatus },
        "ts_code,name,list_date,delist_date,list_status",
        { ttlSeconds: 24 * 3600, refresh: force },
      ),
    ),
  );
  const stockMeta = new Map(
    stockStatuses.flat().map((stock) => [stock.ts_code, stock]),
  );

  const existing = force
    ? { observations: [], generated_at: null }
    : await readJson(baselinePath, { observations: [], generated_at: null });
  const existingDates = new Set(existing.observations.map((item) => item.trade_date));
  const progress = {
    status: "running",
    started_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    start_date: startDate,
    end_date: endDate,
    years,
    done: existingDates.size,
    total: null,
    current_date: null,
    error: null,
  };
  await writeJson(progressPath, progress);

  const calendar = await client.request(
    "trade_cal",
    {
      exchange: "SSE",
      start_date: compactDate(startDate),
      end_date: compactDate(endDate),
      is_open: "1",
    },
    "exchange,cal_date,is_open,pretrade_date",
    { ttlSeconds: 24 * 3600, refresh: force },
  );
  const dates = calendar
    .map((row) => String(row.cal_date))
    .filter(Boolean)
    .sort()
    .map(
      (value) =>
        `${value.slice(0, 4)}-${value.slice(4, 6)}-${value.slice(6, 8)}`,
    );
  progress.total = dates.length;
  progress.done = dates.filter((date) => existingDates.has(date)).length;
  await writeJson(progressPath, progress);

  const pending = dates.filter((date) => !existingDates.has(date));
  const newObservations = [];
  let completedSinceSave = 0;
  await runPool(pending, concurrency, async (tradeDate) => {
    try {
      const [rows, stRows] = await Promise.all([
        client.request(
          "daily",
          { trade_date: compactDate(tradeDate) },
          "ts_code,trade_date,pct_chg",
          { ttlSeconds: 365 * 24 * 3600, persistCache: false },
        ),
        client.request(
          "stock_st",
          { trade_date: compactDate(tradeDate) },
          "ts_code,trade_date,type",
          { ttlSeconds: 365 * 24 * 3600, persistCache: false },
        ),
      ]);
      const stCodes = new Set(stRows.map((row) => row.ts_code));
      const compactTradeDate = compactDate(tradeDate);
      const tradeTimestamp = Date.parse(`${tradeDate}T00:00:00Z`);
      const changes = rows
        .filter((row) => {
          if (!/(\.SH|\.SZ)$/.test(row.ts_code) || stCodes.has(row.ts_code)) return false;
          const stock = stockMeta.get(row.ts_code);
          if (!stock?.list_date || String(stock.list_date) > compactTradeDate) return false;
          if (stock.delist_date && String(stock.delist_date) < compactTradeDate) return false;
          const listTimestamp = Date.parse(
            `${String(stock.list_date).slice(0, 4)}-${String(stock.list_date).slice(4, 6)}-${String(stock.list_date).slice(6, 8)}T00:00:00Z`,
          );
          return Number.isFinite(listTimestamp) && tradeTimestamp - listTimestamp >= 90 * 86_400_000;
        })
        .map((row) => Number(row.pct_chg) / 100)
        .filter(Number.isFinite);
      if (changes.length >= 100) {
        newObservations.push({
          trade_date: tradeDate,
          sample_size: changes.length,
          left_tail_raw: -(quantile(changes, 0.05) ?? 0),
          dispersion_raw: (quantile(changes, 0.75) ?? 0) - (quantile(changes, 0.25) ?? 0),
        });
      }
      existingDates.add(tradeDate);
      progress.done = existingDates.size;
      progress.current_date = tradeDate;
      progress.updated_at = new Date().toISOString();
      completedSinceSave += 1;
      if (completedSinceSave >= 20) {
        completedSinceSave = 0;
        const observations = [
          ...existing.observations,
          ...newObservations,
        ].sort((left, right) => left.trade_date.localeCompare(right.trade_date));
        await writeJson(progressPath, progress);
        await writeJson(baselinePath, {
          generated_at: new Date().toISOString(),
          start_date: startDate,
          end_date: endDate,
          years,
          complete: false,
          observations,
        });
      }
    } catch (error) {
      progress.status = "failed";
      progress.error = error.message;
      progress.updated_at = new Date().toISOString();
      await writeJson(progressPath, progress);
      throw error;
    }
  });

  const observations = [...existing.observations, ...newObservations].sort((left, right) =>
    left.trade_date.localeCompare(right.trade_date),
  );
  const baseline = {
    generated_at: new Date().toISOString(),
    start_date: startDate,
    end_date: endDate,
    years,
    complete: observations.length >= 250,
    observations,
  };
  progress.status = "complete";
  progress.done = observations.length;
  progress.total = dates.length;
  progress.updated_at = new Date().toISOString();
  await writeJson(baselinePath, baseline);
  await writeJson(progressPath, progress);
  return { baseline, progress };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  warmupBaseline({
    years: Number(argument("years", config.warmupYears)),
    startDate: argument("from"),
    endDate: argument("to"),
    concurrency: Number(argument("concurrency", 3)),
    requestsPerMinute: Number(argument("rpm", config.requestsPerMinute)),
    force: hasFlag("force"),
  })
    .then(({ baseline, progress }) => {
      console.log(
        JSON.stringify(
          {
            status: progress.status,
            observations: baseline.observations.length,
            start_date: baseline.start_date,
            end_date: baseline.end_date,
          },
          null,
          2,
        ),
      );
    })
    .catch((error) => {
      console.error(error.message);
      process.exitCode = 1;
    });
}
