import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { MarketDataService } from "../src/data-service.js";
import { warmupBaseline } from "./warmup-baseline.js";

function argument(name, fallback = "") {
  const index = process.argv.indexOf(`--${name}`);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    return fallback;
  }
}

async function writeJsonAtomic(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${process.pid}.tmp`;
  await fs.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  await fs.rename(temporary, file);
}

const engineRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataDir = path.resolve(argument("data-dir", path.join(engineRoot, "data")));
const output = path.resolve(argument("output", path.join(dataDir, "latest-live-report.json")));
const asOfCompact = argument("as-of").replaceAll("-", "");
if (!/^\d{8}$/.test(asOfCompact)) throw new Error("必须提供 --as-of YYYYMMDD");
if (!process.env.TUSHARE_TOKEN?.trim()) throw new Error("未配置 TUSHARE_TOKEN");
const asOf = `${asOfCompact.slice(0, 4)}-${asOfCompact.slice(4, 6)}-${asOfCompact.slice(6, 8)}`;

console.log(JSON.stringify({ event: "baseline_update_started", asOf }));
await warmupBaseline({
  years: 5,
  startDate: `${Number(asOf.slice(0, 4)) - 5}${asOf.slice(4)}`,
  endDate: asOf,
  dataDir,
  concurrency: 1,
  requestsPerMinute: 100,
});

const historyPath = path.join(dataDir, "reports.json");
const history = await readJson(historyPath, []);
const service = new MarketDataService({ dataDir });
console.log(JSON.stringify({ event: "market_snapshot_started", asOf }));
const report = await service.collect({ refresh: true, historyReports: history, asOf });
if (report.trade_date !== asOf) {
  throw new Error(`行情未闭合：请求 ${asOf}，实际最新交易日 ${report.trade_date}`);
}
if (report.data_status !== "complete" || report.data_quality?.complete_modules !== 6) {
  throw new Error(`A–F 数据未完整闭合：${report.data_quality?.complete_modules || 0}/6`);
}
const unhealthy = (report.data_quality?.sources || []).filter((source) => source.status !== "ok");
if (unhealthy.length) {
  throw new Error(`数据源质量检查未通过：${unhealthy.map((source) => `${source.name}=${source.status}`).join("；")}`);
}
if (!Number.isFinite(report.total_score) || report.total_score < 0 || report.total_score > 100) {
  throw new Error("综合分缺失或超出 0–100 范围");
}

const nextHistory = history.filter((item) => item.trade_date !== report.trade_date);
nextHistory.push(report);
nextHistory.sort((left, right) => left.trade_date.localeCompare(right.trade_date));
await writeJsonAtomic(historyPath, nextHistory.slice(-180));
await writeJsonAtomic(output, report);
await writeJsonAtomic(path.join(dataDir, "latest-live-report.json"), report);
console.log(JSON.stringify({
  event: "market_snapshot_complete",
  tradeDate: report.trade_date,
  generatedAt: report.generated_at,
  state: report.market_state,
  score: report.total_score,
  baselineSessions: report.data_quality.baseline_sessions,
}));
