from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, time as clock_time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "work"
ENGINE_DATA = WORK / "engine-data"
STAGING = WORK / "staging"
PUBLIC_DATA = ROOT / "public/data"
STATE = ROOT / "state"
SHANGHAI = ZoneInfo("Asia/Shanghai")


def log(event, **fields):
    print(json.dumps({"event": event, **fields}, ensure_ascii=False), flush=True)


def api_call(token, api_name, params, fields):
    body = json.dumps({"api_name": api_name, "token": token, "params": params, "fields": fields}).encode("utf-8")
    request = urllib.request.Request("https://api.tushare.pro", data=body, headers={"Content-Type": "application/json", "User-Agent": "market-state-cloud/1.0"})
    last_error = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                payload = json.loads(response.read().decode("utf-8"))
            if payload.get("code") != 0:
                raise RuntimeError(str(payload.get("msg", "Tushare 接口错误")).replace(token, "[已隐藏]"))
            data = payload.get("data") or {}
            return [dict(zip(data.get("fields") or [], values)) for values in data.get("items") or []]
        except Exception as exc:
            last_error = str(exc).replace(token, "[已隐藏]")
            if attempt < 2:
                time.sleep(5 * (attempt + 1))
    raise RuntimeError(f"{api_name}: {last_error}")


def run_command(args, env):
    log("command_started", command=Path(args[0]).name)
    result = subprocess.run(args, cwd=ROOT, env=env, check=False)
    if result.returncode:
        raise RuntimeError(f"命令失败（{result.returncode}）：{Path(args[0]).name}")


def target_trade_date(token, scheduled, now):
    start = (now.date() - timedelta(days=20)).strftime("%Y%m%d")
    today = now.date().strftime("%Y%m%d")
    rows = api_call(token, "trade_cal", {"exchange": "SSE", "start_date": start, "end_date": today, "is_open": "1"}, "exchange,cal_date,is_open,pretrade_date")
    open_dates = sorted(str(row["cal_date"]) for row in rows if str(row.get("is_open")) == "1")
    if not open_dates:
        raise RuntimeError("最近 20 天未取得交易日历")
    if scheduled:
        if today not in open_dates:
            return None, today, "今天不是交易日"
        if now.time() < clock_time(16, 30):
            raise RuntimeError("当前交易日尚未到收盘数据检查时间")
        return today, today, ""
    completed = [date for date in open_dates if date < today or (date == today and now.time() >= clock_time(15, 30))]
    if not completed:
        raise RuntimeError("尚无已收盘交易日")
    target = completed[-1]
    return target, target, ""


def write_status(as_of, fetched_at, skipped, summary):
    PUBLIC_DATA.mkdir(parents=True, exist_ok=True)
    payload = {"asOf": as_of, "fetchedAt": fetched_at, "skipped": skipped, "summary": summary, "stale": False, "source": "GitHub Actions + Tushare Pro"}
    (PUBLIC_DATA / "cloud-status.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scheduled", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("TUSHARE_TOKEN", "").strip()
    if not token:
        raise RuntimeError("未配置 TUSHARE_TOKEN")
    now = datetime.now(SHANGHAI)
    as_of, requested, reason = target_trade_date(token, args.scheduled, now)
    if not as_of:
        write_status(requested, now.isoformat(timespec="seconds"), True, reason + "，保留上一份快照。")
        log("cloud_update_skipped", reason=reason)
        return

    if ENGINE_DATA.exists():
        shutil.rmtree(ENGINE_DATA)
    ENGINE_DATA.mkdir(parents=True)
    shutil.copy2(STATE / "baseline.json", ENGINE_DATA / "baseline.json")
    shutil.copy2(STATE / "reports.json", ENGINE_DATA / "reports.json")
    if STAGING.exists():
        shutil.rmtree(STAGING)
    STAGING.mkdir(parents=True)
    env = os.environ.copy()
    env.update({
        "TUSHARE_TOKEN": token,
        "MARKET_AS_OF": as_of,
        "MARKET_CORE_CACHE": str(ROOT / "engine/data/cache"),
        "MARKET_ENRICHMENT_CACHE": str(WORK / "enrichment-cache"),
        "MARKET_DATA_OUTPUT": str(STAGING),
    })
    log("cloud_update_started", asOf=as_of, scheduled=args.scheduled)
    run_command(["node", str(ROOT / "engine/scripts/update-snapshot.mjs"), "--as-of", as_of, "--data-dir", str(ENGINE_DATA), "--output", str(STAGING / "market-state.json")], env)
    run_command([sys.executable, str(ROOT / "references/build_current_enrichment.py"), "--refresh"], env)
    run_command([sys.executable, str(ROOT / "references/validate_current_snapshot.py")], env)

    PUBLIC_DATA.mkdir(parents=True, exist_ok=True)
    for name in ("market-state.json", "industry-rankings.json", "stock-pool-current.json"):
        shutil.copy2(STAGING / name, PUBLIC_DATA / name)
    run_command([
        sys.executable,
        str(ROOT / "scripts/build-history-summary.py"),
        "--existing", str(PUBLIC_DATA / "history-summary.json"),
        "--append-report", str(PUBLIC_DATA / "market-state.json"),
        "--output", str(PUBLIC_DATA / "history-summary.json"),
    ], env)
    shutil.copy2(ENGINE_DATA / "baseline.json", STATE / "baseline.json")
    shutil.copy2(ENGINE_DATA / "reports.json", STATE / "reports.json")
    market = json.loads((PUBLIC_DATA / "market-state.json").read_text(encoding="utf-8"))
    pool = json.loads((PUBLIC_DATA / "stock-pool-current.json").read_text(encoding="utf-8"))
    summary = f"{market['trade_date']} 收盘快照已生成，状态为{market['market_state']}，综合分 {market['total_score']:.2f}。"
    write_status(market["trade_date"], market["generated_at"], False, summary)
    log("cloud_update_succeeded", asOf=market["trade_date"], state=market["market_state"], score=market["total_score"], financialPass=pool["counts"]["financial_pass"])


if __name__ == "__main__":
    main()
