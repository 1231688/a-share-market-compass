from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
INDEX_CODES = {"000001.SH": "上证指数", "399001.SZ": "深证成指", "399006.SZ": "创业板指"}
STATE_NAMES = {"attack": "进攻", "neutral": "中性", "defense": "防守", "unavailable": "数据未闭合"}
PRIMARY_HORIZONS = (20, 60, 120)
DIAGNOSTIC_HORIZONS = (1, 3, 5)
ALL_HORIZONS = (*PRIMARY_HORIZONS, *DIAGNOSTIC_HORIZONS)
COST_BPS = 5


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def finite(value):
    return value is not None and isinstance(value, (int, float)) and math.isfinite(value)


def clean(value, digits=8):
    if not finite(value):
        return None
    return round(float(value), digits)


def max_drawdown(values):
    array = np.asarray(values, dtype=float)
    if not len(array):
        return None
    array = np.concatenate(([1.0], array))
    peaks = np.maximum.accumulate(array)
    return float(np.min(array / peaks - 1))


def annualized_return(equity, observations):
    if not observations or not finite(equity) or equity <= 0:
        return None
    return float(equity ** (252 / observations) - 1)


def sharpe(returns):
    values = np.asarray(returns, dtype=float)
    if len(values) < 2:
        return None
    deviation = float(np.std(values, ddof=1))
    return float(np.mean(values) / deviation * math.sqrt(252)) if deviation > 0 else None


def metric_block(model_returns, benchmark_returns, exposures=None):
    model = np.asarray(model_returns, dtype=float)
    benchmark = np.asarray(benchmark_returns, dtype=float)
    model_equity = np.cumprod(1 + model)
    benchmark_equity = np.cumprod(1 + benchmark)
    model_total = float(model_equity[-1] - 1) if len(model) else None
    benchmark_total = float(benchmark_equity[-1] - 1) if len(benchmark) else None
    return {
        "observations": int(len(model)),
        "model_return": clean(model_total),
        "benchmark_return": clean(benchmark_total),
        "excess_return": clean(model_total - benchmark_total) if model_total is not None else None,
        "model_annualized_return": clean(annualized_return(model_equity[-1], len(model))) if len(model) else None,
        "benchmark_annualized_return": clean(annualized_return(benchmark_equity[-1], len(benchmark))) if len(benchmark) else None,
        "model_max_drawdown": clean(max_drawdown(model_equity)),
        "benchmark_max_drawdown": clean(max_drawdown(benchmark_equity)),
        "model_sharpe": clean(sharpe(model), 4),
        "benchmark_sharpe": clean(sharpe(benchmark), 4),
        "average_exposure": clean(float(np.mean(exposures))) if exposures is not None and len(exposures) else None,
    }


def compact_report(report):
    modules = {}
    for key in "ABCDEF":
        module = report.get("modules", {}).get(key, {})
        meta = report.get("module_meta", {}).get(key, {})
        modules[key] = {
            "score": clean(module.get("score")),
            "max": module.get("max"),
            "name": meta.get("name") or key,
            "driver": meta.get("driver") or "历史快照未提供文字驱动",
            "status": module.get("status") or meta.get("status") or "unavailable",
            "subitems": {
                subkey: {"score": clean(item.get("score")), "max": item.get("max")}
                for subkey, item in (module.get("subitems") or {}).items()
            },
        }
    indices = {}
    for code, name in INDEX_CODES.items():
        item = report.get("indices", {}).get(code) or {}
        rows = item.get("rows") or []
        row = rows[-1] if rows else {}
        indices[code] = {
            "name": name,
            "open": clean(row.get("open")),
            "close": clean(row.get("close")),
            "change_pct": clean(item.get("change_pct")),
        }
    return {
        "date": report["trade_date"],
        "state": report.get("market_state"),
        "state_label": STATE_NAMES.get(report.get("market_state"), report.get("market_state")),
        "score": clean(report.get("total_score")),
        "trend": report.get("trend_structural_state"),
        "trend_label": STATE_NAMES.get(report.get("trend_structural_state"), report.get("trend_structural_state")),
        "risk": (report.get("risk_overlay") or {}).get("level"),
        "permission": (report.get("execution") or {}).get("permission"),
        "position": clean((report.get("guidance_position_pct") or 0) / 100),
        "attack_counter": report.get("attack_entry_counter"),
        "reason": report.get("state_reason"),
        "modules": modules,
        "indices": indices,
        "forward": {},
    }


def main():
    parser = argparse.ArgumentParser(description="Build the compact historical review and trend-backtest payload.")
    parser.add_argument("--input", type=Path, default=ROOT / "backtest/trend-output/reports.json")
    parser.add_argument("--output", type=Path, default=ROOT / "app/public/data/history-summary.json")
    parser.add_argument("--existing", type=Path, help="Existing history-summary.json for incremental daily updates")
    parser.add_argument("--append-report", type=Path, help="Latest full market-state.json to append or replace")
    args = parser.parse_args()

    if bool(args.existing) != bool(args.append_report):
        raise SystemExit("--existing 与 --append-report 必须同时提供")
    if args.existing:
        existing = read_json(args.existing)
        reports = []
        for day in existing.get("days", []):
            reports.append({
                "trade_date": day["date"],
                "data_status": "complete",
                "total_score": day["score"],
                "guidance_position_pct": day["position"] * 100,
                "market_state": day["state"],
                "trend_structural_state": day["trend"],
                "risk_overlay": {"level": day["risk"]},
                "execution": {"permission": day["permission"]},
                "attack_entry_counter": day["attack_counter"],
                "state_reason": day["reason"],
                "modules": day["modules"],
                "module_meta": {key: {"name": module["name"], "driver": module["driver"], "status": module["status"]} for key, module in day["modules"].items()},
                "indices": {code: {"change_pct": item["change_pct"], "rows": [{"date": day["date"], "open": item["open"], "close": item["close"]}]} for code, item in day["indices"].items()},
            })
        reports.append(read_json(args.append_report))
    else:
        reports = read_json(args.input)
    reports = sorted({report["trade_date"]: report for report in reports if report.get("trade_date")}.values(), key=lambda item: item["trade_date"])
    reports = [
        report for report in reports
        if report.get("trade_date")
        and report.get("data_status") == "complete"
        and finite(report.get("total_score"))
        and finite(report.get("guidance_position_pct"))
        and all(code in (report.get("indices") or {}) for code in INDEX_CODES)
    ]
    if len(reports) < 3:
        raise SystemExit("完整历史报告不足 3 日，拒绝生成误导性回测。")

    dates = [report["trade_date"] for report in reports]
    market = {code: {} for code in INDEX_CODES}
    for report in reports:
        for code in INDEX_CODES:
            rows = report["indices"][code].get("rows") or []
            row = rows[-1]
            if row.get("date") != report["trade_date"]:
                raise ValueError(f"{report['trade_date']} {code} 最后一行指数日期不一致")
            if not finite(row.get("open")) or not finite(row.get("close")) or row["open"] <= 0 or row["close"] <= 0:
                raise ValueError(f"{report['trade_date']} {code} OHLC 不完整")
            market[code][report["trade_date"]] = {"open": float(row["open"]), "close": float(row["close"])}

    days = [compact_report(report) for report in reports]
    horizon_samples = defaultdict(lambda: defaultdict(list))
    for i, day in enumerate(days):
        target = day["position"]
        for horizon in ALL_HORIZONS:
            if i + horizon >= len(dates):
                day["forward"][str(horizon)] = None
                continue
            entry_date = dates[i + 1]
            exit_date = dates[i + horizon]
            index_returns = {}
            returns = []
            for code in INDEX_CODES:
                entry = market[code][entry_date]["open"]
                exit_ = market[code][exit_date]["close"]
                value = exit_ / entry - 1
                index_returns[code] = clean(value)
                returns.append(value)
            benchmark_return = float(np.mean(returns))
            # Fixed exposure diagnostic: enter at T+1 open, hold N sessions, then exit.
            model_return = target * benchmark_return - 2 * target * COST_BPS / 10000
            result = {
                "entry_date": entry_date,
                "end_date": exit_date,
                "benchmark_return": clean(benchmark_return),
                "model_return": clean(model_return),
                "excess_return": clean(model_return - benchmark_return),
                "indices": index_returns,
            }
            day["forward"][str(horizon)] = result
            horizon_samples[str(horizon)][day["state"]].append(result)

    position = 0.0
    strategy_rows = []
    model_equity = 1.0
    benchmark_equity = 1.0
    model_peak = 1.0
    benchmark_peak = 1.0
    for i in range(len(reports) - 2):
        signal = reports[i]
        entry_date = dates[i + 1]
        exit_date = dates[i + 2]
        target = float(signal["guidance_position_pct"]) / 100
        permission = (signal.get("execution") or {}).get("permission")
        executed = min(position, target) if permission in {"no_new_risk", "hold_or_reduce"} else target
        benchmark_return = float(np.mean([
            market[code][exit_date]["open"] / market[code][entry_date]["open"] - 1
            for code in INDEX_CODES
        ]))
        turnover = abs(executed - position)
        strategy_return = executed * benchmark_return - turnover * COST_BPS / 10000
        model_equity *= 1 + strategy_return
        benchmark_equity *= 1 + benchmark_return
        model_peak = max(model_peak, model_equity)
        benchmark_peak = max(benchmark_peak, benchmark_equity)
        strategy_rows.append({
            "date": exit_date,
            "signal_date": signal["trade_date"],
            "state": signal["market_state"],
            "score": clean(signal["total_score"]),
            "model": clean(model_equity),
            "benchmark": clean(benchmark_equity),
            "model_drawdown": clean(model_equity / model_peak - 1),
            "benchmark_drawdown": clean(benchmark_equity / benchmark_peak - 1),
            "exposure": clean(executed),
            "model_return": clean(strategy_return),
            "benchmark_return": clean(benchmark_return),
        })
        position = executed

    model_returns = [row["model_return"] for row in strategy_rows]
    benchmark_returns = [row["benchmark_return"] for row in strategy_rows]
    exposures = [row["exposure"] for row in strategy_rows]
    metrics = metric_block(model_returns, benchmark_returns, exposures)

    # A non-executable diagnostic that holds the full-sample average exposure constant.
    # It separates dynamic timing from the mechanical effect of simply holding less risk.
    average_exposure = float(np.mean(exposures))
    fixed_equity = 1.0
    fixed_peak = 1.0
    fixed_returns = []
    for row in strategy_rows:
        fixed_return = average_exposure * row["benchmark_return"]
        fixed_returns.append(fixed_return)
        fixed_equity *= 1 + fixed_return
        fixed_peak = max(fixed_peak, fixed_equity)
        row["fixed"] = clean(fixed_equity)
        row["fixed_drawdown"] = clean(fixed_equity / fixed_peak - 1)
    metrics["fixed_exposure_return"] = clean(fixed_equity - 1)
    metrics["timing_excess_return"] = clean((model_equity - 1) - (fixed_equity - 1))
    metrics["fixed_exposure_max_drawdown"] = clean(max_drawdown(np.cumprod(1 + np.asarray(fixed_returns))))
    metrics["fixed_exposure_sharpe"] = clean(sharpe(fixed_returns), 4)

    yearly = []
    years = sorted({row["date"][:4] for row in strategy_rows})
    for year in years:
        selected = [row for row in strategy_rows if row["date"].startswith(year)]
        block = metric_block(
            [row["model_return"] for row in selected],
            [row["benchmark_return"] for row in selected],
            [row["exposure"] for row in selected],
        )
        block.pop("model_annualized_return", None)
        block.pop("benchmark_annualized_return", None)
        yearly.append({"year": year, **block})

    states = []
    for state in ("attack", "neutral", "defense"):
        item = {"state": state, "state_label": STATE_NAMES[state], "days": sum(day["state"] == state for day in days), "horizons": {}}
        for horizon in PRIMARY_HORIZONS:
            samples = horizon_samples[str(horizon)][state]
            item["horizons"][str(horizon)] = {
                "samples": len(samples),
                "average_model_return": clean(float(np.mean([row["model_return"] for row in samples]))) if samples else None,
                "average_benchmark_return": clean(float(np.mean([row["benchmark_return"] for row in samples]))) if samples else None,
                "average_excess_return": clean(float(np.mean([row["excess_return"] for row in samples]))) if samples else None,
                "positive_excess_ratio": clean(float(np.mean([row["excess_return"] > 0 for row in samples]))) if samples else None,
            }
        states.append(item)

    payload = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "range": {
            "first": dates[0],
            "last": dates[-1],
            "trading_days": len(dates),
            "backtest_observations": len(strategy_rows),
            "primary_horizons": list(PRIMARY_HORIZONS),
            "diagnostic_horizons": list(DIAGNOSTIC_HORIZONS),
        },
        "methodology": {
            "benchmark": "上证指数、深证成指、创业板指等权；单日窗口为期初等权，连续回测为每日再平衡。",
            "forward": "T日收盘信号，T+1开盘按当日指导仓位建立固定暴露，持有N个交易日后收盘平仓；N为交易日。",
            "continuous": "每日T日收盘出信号，T+1开盘调仓并持有至T+2开盘；no_new_risk/hold_or_reduce只允许维持或降低暴露。",
            "matched_exposure": "同平均暴露对照始终持有全样本平均实际仓位，不扣动态换手成本；它使用事后平均值，仅用于拆解择时增益，不是可执行策略。",
            "cost": f"连续回测按实际换手单边{COST_BPS}bps；单日固定暴露诊断计入建仓和平仓各{COST_BPS}bps。",
            "cash": "未投资现金收益按0计，不计印花税、滑点、分红和指数可交易性差异。",
            "missing": "未来观察期不足时返回null，绝不按0收益填充。",
            "limitations": "单日前瞻窗口彼此重叠，不能当作独立样本；历史回测不保证样本外有效，需继续做多市场阶段、参数敏感性和真实可交易组合验证。",
        },
        "days": days,
        "backtest": {
            "start": strategy_rows[0]["date"],
            "end": strategy_rows[-1]["date"],
            "metrics": metrics,
            "yearly": yearly,
            "states": states,
            "series": strategy_rows,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
    print(json.dumps({
        "output": str(args.output),
        "days": len(days),
        "first": dates[0],
        "last": dates[-1],
        "metrics": metrics,
        "bytes": args.output.stat().st_size,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
